--
-- PostgreSQL database dump
--

\restrict 9focJabtWCfKmUBWHc8a9CgdGzpnTeKJkzOqHksPof11alCX6gJ9uYOd6yCtgBW

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.platform_core_workspacestate DROP CONSTRAINT IF EXISTS platform_core_worksp_last_saved_by_id_04534df2_fk_auth_user;
ALTER TABLE IF EXISTS ONLY public.platform_core_platformprofile DROP CONSTRAINT IF EXISTS platform_core_platformprofile_user_id_d87b5254_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.platform_core_platformprofile DROP CONSTRAINT IF EXISTS platform_core_platfo_position_id_7f9ce93e_fk_platform_;
ALTER TABLE IF EXISTS ONLY public.platform_core_platformprofile DROP CONSTRAINT IF EXISTS platform_core_platfo_organization_id_9e781a6c_fk_platform_;
ALTER TABLE IF EXISTS ONLY public.platform_core_invitation DROP CONSTRAINT IF EXISTS platform_core_invitation_invited_by_id_a2bf0649_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.platform_core_invitation DROP CONSTRAINT IF EXISTS platform_core_invita_organization_id_ad0ec2b5_fk_platform_;
ALTER TABLE IF EXISTS ONLY public.platform_core_fileobject DROP CONSTRAINT IF EXISTS platform_core_fileobject_owner_id_e8ba510a_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.platform_core_auditevent DROP CONSTRAINT IF EXISTS platform_core_auditevent_actor_id_ae148574_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.platform_core_apisession DROP CONSTRAINT IF EXISTS platform_core_apisession_user_id_f8fccf6b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX IF EXISTS public.platform_core_workspacestate_last_saved_by_id_04534df2;
DROP INDEX IF EXISTS public.platform_core_workspacestate_key_b4ba92f6_like;
DROP INDEX IF EXISTS public.platform_core_position_id_eefe835d_like;
DROP INDEX IF EXISTS public.platform_core_position_family_b9099e95_like;
DROP INDEX IF EXISTS public.platform_core_position_family_b9099e95;
DROP INDEX IF EXISTS public.platform_core_platformrecord_workspace_key_c54d1d98_like;
DROP INDEX IF EXISTS public.platform_core_platformrecord_workspace_key_c54d1d98;
DROP INDEX IF EXISTS public.platform_core_platformrecord_user_ref_5e2c631d_like;
DROP INDEX IF EXISTS public.platform_core_platformrecord_user_ref_5e2c631d;
DROP INDEX IF EXISTS public.platform_core_platformrecord_status_3de215ba_like;
DROP INDEX IF EXISTS public.platform_core_platformrecord_status_3de215ba;
DROP INDEX IF EXISTS public.platform_core_platformrecord_record_type_35f5ee08_like;
DROP INDEX IF EXISTS public.platform_core_platformrecord_record_type_35f5ee08;
DROP INDEX IF EXISTS public.platform_core_platformrecord_organization_id_d9fd22e0_like;
DROP INDEX IF EXISTS public.platform_core_platformrecord_organization_id_d9fd22e0;
DROP INDEX IF EXISTS public.platform_core_platformrecord_country_790631cd_like;
DROP INDEX IF EXISTS public.platform_core_platformrecord_country_790631cd;
DROP INDEX IF EXISTS public.platform_core_platformprofile_system_role_6a372426_like;
DROP INDEX IF EXISTS public.platform_core_platformprofile_system_role_6a372426;
DROP INDEX IF EXISTS public.platform_core_platformprofile_status_1826b8ef_like;
DROP INDEX IF EXISTS public.platform_core_platformprofile_status_1826b8ef;
DROP INDEX IF EXISTS public.platform_core_platformprofile_position_id_7f9ce93e_like;
DROP INDEX IF EXISTS public.platform_core_platformprofile_position_id_7f9ce93e;
DROP INDEX IF EXISTS public.platform_core_platformprofile_platform_user_id_07c29b31_like;
DROP INDEX IF EXISTS public.platform_core_platformprofile_organization_id_9e781a6c_like;
DROP INDEX IF EXISTS public.platform_core_platformprofile_organization_id_9e781a6c;
DROP INDEX IF EXISTS public.platform_core_organization_status_c66743e4_like;
DROP INDEX IF EXISTS public.platform_core_organization_status_c66743e4;
DROP INDEX IF EXISTS public.platform_core_organization_organization_type_bd3594bf_like;
DROP INDEX IF EXISTS public.platform_core_organization_organization_type_bd3594bf;
DROP INDEX IF EXISTS public.platform_core_organization_id_3624710e_like;
DROP INDEX IF EXISTS public.platform_core_organization_country_bc77f3ad_like;
DROP INDEX IF EXISTS public.platform_core_organization_country_bc77f3ad;
DROP INDEX IF EXISTS public.platform_core_invitation_token_hash_06529885_like;
DROP INDEX IF EXISTS public.platform_core_invitation_organization_id_ad0ec2b5_like;
DROP INDEX IF EXISTS public.platform_core_invitation_organization_id_ad0ec2b5;
DROP INDEX IF EXISTS public.platform_core_invitation_invited_by_id_a2bf0649;
DROP INDEX IF EXISTS public.platform_core_invitation_expires_at_9d453a46;
DROP INDEX IF EXISTS public.platform_core_invitation_email_797f6570_like;
DROP INDEX IF EXISTS public.platform_core_invitation_email_797f6570;
DROP INDEX IF EXISTS public.platform_core_fileobject_sha256_90e5c52c_like;
DROP INDEX IF EXISTS public.platform_core_fileobject_sha256_90e5c52c;
DROP INDEX IF EXISTS public.platform_core_fileobject_owner_id_e8ba510a;
DROP INDEX IF EXISTS public.platform_core_fileobject_organization_id_b9a5561c_like;
DROP INDEX IF EXISTS public.platform_core_fileobject_organization_id_b9a5561c;
DROP INDEX IF EXISTS public.platform_core_fileobject_category_46c31a50_like;
DROP INDEX IF EXISTS public.platform_core_fileobject_category_46c31a50;
DROP INDEX IF EXISTS public.platform_core_auditevent_organization_id_dd9f8f97_like;
DROP INDEX IF EXISTS public.platform_core_auditevent_organization_id_dd9f8f97;
DROP INDEX IF EXISTS public.platform_core_auditevent_occurred_at_e287ed7c;
DROP INDEX IF EXISTS public.platform_core_auditevent_entity_type_99891c4d_like;
DROP INDEX IF EXISTS public.platform_core_auditevent_entity_type_99891c4d;
DROP INDEX IF EXISTS public.platform_core_auditevent_entity_id_778502c7_like;
DROP INDEX IF EXISTS public.platform_core_auditevent_entity_id_778502c7;
DROP INDEX IF EXISTS public.platform_core_auditevent_actor_id_ae148574;
DROP INDEX IF EXISTS public.platform_core_auditevent_action_5abd11b4_like;
DROP INDEX IF EXISTS public.platform_core_auditevent_action_5abd11b4;
DROP INDEX IF EXISTS public.platform_core_apisession_user_id_f8fccf6b;
DROP INDEX IF EXISTS public.platform_core_apisession_token_hash_e9cc032a_like;
DROP INDEX IF EXISTS public.platform_core_apisession_expires_at_93debae3;
DROP INDEX IF EXISTS public.platform_co_record__9bc5c1_idx;
DROP INDEX IF EXISTS public.platform_co_record__8a2911_idx;
DROP INDEX IF EXISTS public.django_session_session_key_c0390e0f_like;
DROP INDEX IF EXISTS public.django_session_expire_date_a5c62663;
DROP INDEX IF EXISTS public.django_admin_log_user_id_c564eba6;
DROP INDEX IF EXISTS public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX IF EXISTS public.auth_user_username_6821ab7c_like;
DROP INDEX IF EXISTS public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX IF EXISTS public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX IF EXISTS public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX IF EXISTS public.auth_user_groups_group_id_97559544;
DROP INDEX IF EXISTS public.auth_permission_content_type_id_2f476e4b;
DROP INDEX IF EXISTS public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX IF EXISTS public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX IF EXISTS public.auth_group_name_a6ea08ec_like;
ALTER TABLE IF EXISTS ONLY public.platform_core_platformrecord DROP CONSTRAINT IF EXISTS uniq_platform_record;
ALTER TABLE IF EXISTS ONLY public.platform_core_workspacestate DROP CONSTRAINT IF EXISTS platform_core_workspacestate_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_core_position DROP CONSTRAINT IF EXISTS platform_core_position_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_core_platformrecord DROP CONSTRAINT IF EXISTS platform_core_platformrecord_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_core_platformprofile DROP CONSTRAINT IF EXISTS platform_core_platformprofile_user_id_key;
ALTER TABLE IF EXISTS ONLY public.platform_core_platformprofile DROP CONSTRAINT IF EXISTS platform_core_platformprofile_platform_user_id_key;
ALTER TABLE IF EXISTS ONLY public.platform_core_platformprofile DROP CONSTRAINT IF EXISTS platform_core_platformprofile_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_core_organization DROP CONSTRAINT IF EXISTS platform_core_organization_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_core_invitation DROP CONSTRAINT IF EXISTS platform_core_invitation_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.platform_core_invitation DROP CONSTRAINT IF EXISTS platform_core_invitation_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_core_fileobject DROP CONSTRAINT IF EXISTS platform_core_fileobject_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_core_auditevent DROP CONSTRAINT IF EXISTS platform_core_auditevent_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_core_apisession DROP CONSTRAINT IF EXISTS platform_core_apisession_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.platform_core_apisession DROP CONSTRAINT IF EXISTS platform_core_apisession_pkey;
ALTER TABLE IF EXISTS ONLY public.django_session DROP CONSTRAINT IF EXISTS django_session_pkey;
ALTER TABLE IF EXISTS ONLY public.django_migrations DROP CONSTRAINT IF EXISTS django_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_username_key;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_name_key;
DROP TABLE IF EXISTS public.platform_core_workspacestate;
DROP TABLE IF EXISTS public.platform_core_position;
DROP TABLE IF EXISTS public.platform_core_platformrecord;
DROP TABLE IF EXISTS public.platform_core_platformprofile;
DROP TABLE IF EXISTS public.platform_core_organization;
DROP TABLE IF EXISTS public.platform_core_invitation;
DROP TABLE IF EXISTS public.platform_core_fileobject;
DROP TABLE IF EXISTS public.platform_core_auditevent;
DROP TABLE IF EXISTS public.platform_core_apisession;
DROP TABLE IF EXISTS public.django_session;
DROP TABLE IF EXISTS public.django_migrations;
DROP TABLE IF EXISTS public.django_content_type;
DROP TABLE IF EXISTS public.django_admin_log;
DROP TABLE IF EXISTS public.auth_user_user_permissions;
DROP TABLE IF EXISTS public.auth_user_groups;
DROP TABLE IF EXISTS public.auth_user;
DROP TABLE IF EXISTS public.auth_permission;
DROP TABLE IF EXISTS public.auth_group_permissions;
DROP TABLE IF EXISTS public.auth_group;
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pg_trgm;
--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO t4f_app;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO t4f_app;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO t4f_app;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO t4f_app;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO t4f_app;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO t4f_app;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO t4f_app;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO t4f_app;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO t4f_app;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO t4f_app;

--
-- Name: platform_core_apisession; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_apisession (
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    user_agent text NOT NULL,
    ip_address inet,
    user_id integer NOT NULL
);


ALTER TABLE public.platform_core_apisession OWNER TO t4f_app;

--
-- Name: platform_core_auditevent; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_auditevent (
    id uuid NOT NULL,
    organization_id character varying(120) NOT NULL,
    action character varying(180) NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id character varying(180) NOT NULL,
    detail jsonb NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    actor_id integer
);


ALTER TABLE public.platform_core_auditevent OWNER TO t4f_app;

--
-- Name: platform_core_fileobject; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_fileobject (
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    id uuid NOT NULL,
    organization_id character varying(120) NOT NULL,
    category character varying(100) NOT NULL,
    original_name character varying(255) NOT NULL,
    stored_file character varying(100) NOT NULL,
    mime_type character varying(160) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    classification character varying(80) NOT NULL,
    metadata jsonb NOT NULL,
    owner_id integer
);


ALTER TABLE public.platform_core_fileobject OWNER TO t4f_app;

--
-- Name: platform_core_invitation; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_invitation (
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    id uuid NOT NULL,
    email character varying(254) NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    accepted_at timestamp with time zone,
    metadata jsonb NOT NULL,
    invited_by_id integer,
    organization_id character varying(120)
);


ALTER TABLE public.platform_core_invitation OWNER TO t4f_app;

--
-- Name: platform_core_organization; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_organization (
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    id character varying(120) NOT NULL,
    name character varying(255) NOT NULL,
    organization_type character varying(80) NOT NULL,
    country character varying(120) NOT NULL,
    parent_id character varying(120) NOT NULL,
    status character varying(40) NOT NULL,
    contact jsonb NOT NULL,
    metadata jsonb NOT NULL
);


ALTER TABLE public.platform_core_organization OWNER TO t4f_app;

--
-- Name: platform_core_platformprofile; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_platformprofile (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    platform_user_id character varying(160) NOT NULL,
    system_role character varying(80) NOT NULL,
    status character varying(40) NOT NULL,
    must_reset boolean NOT NULL,
    profile_data jsonb NOT NULL,
    invited_at timestamp with time zone,
    last_seen_at timestamp with time zone,
    organization_id character varying(120),
    position_id character varying(150),
    user_id integer NOT NULL
);


ALTER TABLE public.platform_core_platformprofile OWNER TO t4f_app;

--
-- Name: platform_core_platformprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.platform_core_platformprofile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.platform_core_platformprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: platform_core_platformrecord; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_platformrecord (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    workspace_key character varying(100) NOT NULL,
    record_type character varying(80) NOT NULL,
    record_id character varying(180) NOT NULL,
    organization_id character varying(120) NOT NULL,
    country character varying(120) NOT NULL,
    user_ref character varying(160) NOT NULL,
    status character varying(80) NOT NULL,
    data jsonb NOT NULL
);


ALTER TABLE public.platform_core_platformrecord OWNER TO t4f_app;

--
-- Name: platform_core_platformrecord_id_seq; Type: SEQUENCE; Schema: public; Owner: t4f_app
--

ALTER TABLE public.platform_core_platformrecord ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.platform_core_platformrecord_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: platform_core_position; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_position (
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    id character varying(150) NOT NULL,
    title character varying(255) NOT NULL,
    family character varying(80) NOT NULL,
    "group" character varying(180) NOT NULL,
    reports_to character varying(255) NOT NULL,
    role_purpose text NOT NULL,
    metadata jsonb NOT NULL
);


ALTER TABLE public.platform_core_position OWNER TO t4f_app;

--
-- Name: platform_core_workspacestate; Type: TABLE; Schema: public; Owner: t4f_app
--

CREATE TABLE public.platform_core_workspacestate (
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    key character varying(100) NOT NULL,
    revision bigint NOT NULL,
    state jsonb NOT NULL,
    last_saved_by_id integer
);


ALTER TABLE public.platform_core_workspacestate OWNER TO t4f_app;

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	3	add_permission
6	Can change permission	3	change_permission
7	Can delete permission	3	delete_permission
8	Can view permission	3	view_permission
9	Can add group	2	add_group
10	Can change group	2	change_group
11	Can delete group	2	delete_group
12	Can view group	2	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add organization	11	add_organization
26	Can change organization	11	change_organization
27	Can delete organization	11	delete_organization
28	Can view organization	11	view_organization
29	Can add position	14	add_position
30	Can change position	14	change_position
31	Can delete position	14	delete_position
32	Can view position	14	view_position
33	Can add workspace state	15	add_workspacestate
34	Can change workspace state	15	change_workspacestate
35	Can delete workspace state	15	delete_workspacestate
36	Can view workspace state	15	view_workspacestate
37	Can add platform profile	12	add_platformprofile
38	Can change platform profile	12	change_platformprofile
39	Can delete platform profile	12	delete_platformprofile
40	Can view platform profile	12	view_platformprofile
41	Can add api session	7	add_apisession
42	Can change api session	7	change_apisession
43	Can delete api session	7	delete_apisession
44	Can view api session	7	view_apisession
45	Can add platform record	13	add_platformrecord
46	Can change platform record	13	change_platformrecord
47	Can delete platform record	13	delete_platformrecord
48	Can view platform record	13	view_platformrecord
49	Can add audit event	8	add_auditevent
50	Can change audit event	8	change_auditevent
51	Can delete audit event	8	delete_auditevent
52	Can view audit event	8	view_auditevent
53	Can add file object	9	add_fileobject
54	Can change file object	9	change_fileobject
55	Can delete file object	9	delete_fileobject
56	Can view file object	9	view_fileobject
57	Can add invitation	10	add_invitation
58	Can change invitation	10	change_invitation
59	Can delete invitation	10	delete_invitation
60	Can view invitation	10	view_invitation
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$1500000$6wo6LSov4mB93pFqPCC9hr$WA2ibdGdMRL2NKcrf5GSlLfLD2Z+YLjnghP/yzh+E60=	\N	t	admin@t4f-global.org	Tech4Future-Global	Super Administrator	admin@t4f-global.org	t	t	2026-10-29 12:57:33.599641+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	group
3	auth	permission
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	platform_core	apisession
8	platform_core	auditevent
9	platform_core	fileobject
10	platform_core	invitation
11	platform_core	organization
12	platform_core	platformprofile
13	platform_core	platformrecord
14	platform_core	position
15	platform_core	workspacestate
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-10-29 12:57:21.464054+00
2	auth	0001_initial	2026-10-29 12:57:21.531557+00
3	admin	0001_initial	2026-10-29 12:57:21.554173+00
4	admin	0002_logentry_remove_auto_add	2026-10-29 12:57:21.56639+00
5	admin	0003_logentry_add_action_flag_choices	2026-10-29 12:57:21.573615+00
6	contenttypes	0002_remove_content_type_name	2026-10-29 12:57:21.590911+00
7	auth	0002_alter_permission_name_max_length	2026-10-29 12:57:21.601462+00
8	auth	0003_alter_user_email_max_length	2026-10-29 12:57:21.610695+00
9	auth	0004_alter_user_username_opts	2026-10-29 12:57:21.618756+00
10	auth	0005_alter_user_last_login_null	2026-10-29 12:57:21.628792+00
11	auth	0006_require_contenttypes_0002	2026-10-29 12:57:21.631501+00
12	auth	0007_alter_validators_add_error_messages	2026-10-29 12:57:21.63923+00
13	auth	0008_alter_user_username_max_length	2026-10-29 12:57:21.652342+00
14	auth	0009_alter_user_last_name_max_length	2026-10-29 12:57:21.662453+00
15	auth	0010_alter_group_name_max_length	2026-10-29 12:57:21.673084+00
16	auth	0011_update_proxy_permissions	2026-10-29 12:57:21.681074+00
17	auth	0012_alter_user_first_name_max_length	2026-10-29 12:57:21.690114+00
18	platform_core	0001_initial	2026-10-29 12:57:21.907241+00
19	sessions	0001_initial	2026-10-29 12:57:21.930361+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: platform_core_apisession; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_apisession (created_at, updated_at, id, token_hash, expires_at, revoked_at, user_agent, ip_address, user_id) FROM stdin;
\.


--
-- Data for Name: platform_core_auditevent; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_auditevent (id, organization_id, action, entity_type, entity_id, detail, occurred_at, actor_id) FROM stdin;
\.


--
-- Data for Name: platform_core_fileobject; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_fileobject (created_at, updated_at, id, organization_id, category, original_name, stored_file, mime_type, size_bytes, sha256, classification, metadata, owner_id) FROM stdin;
\.


--
-- Data for Name: platform_core_invitation; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_invitation (created_at, updated_at, id, email, token_hash, expires_at, accepted_at, metadata, invited_by_id, organization_id) FROM stdin;
\.


--
-- Data for Name: platform_core_organization; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_organization (created_at, updated_at, id, name, organization_type, country, parent_id, status, contact, metadata) FROM stdin;
2026-10-29 12:57:33.165769+00	2026-10-29 12:57:33.165784+00	t4f-hq	Tech4Future-Global Headquarters	t4f_hq	United States		Active	{}	{"id": "t4f-hq", "name": "Tech4Future-Global Headquarters", "type": "t4f_hq", "status": "Active", "country": "United States", "parentId": null}
2026-10-29 12:57:33.170011+00	2026-10-29 12:57:33.170022+00	fmw	FMW Nonprofit Solutions	fiscal_sponsor	United States		Active	{}	{"id": "fmw", "name": "FMW Nonprofit Solutions", "type": "fiscal_sponsor", "status": "Active", "country": "United States", "parentId": null}
2026-10-29 12:57:33.173339+00	2026-10-29 12:57:33.173349+00	t4f-benin	Tech4Future-Benin	country_office	Benin	t4f-hq	Planned	{}	{"id": "t4f-benin", "name": "Tech4Future-Benin", "type": "country_office", "status": "Planned", "country": "Benin", "parentId": "t4f-hq"}
2026-10-29 12:57:33.177599+00	2026-10-29 12:57:33.17761+00	t4f-burkina-faso	Tech4Future-Burkina Faso	country_office	Burkina Faso	t4f-hq	Planned	{}	{"id": "t4f-burkina-faso", "name": "Tech4Future-Burkina Faso", "type": "country_office", "status": "Planned", "country": "Burkina Faso", "parentId": "t4f-hq"}
2026-10-29 12:57:33.181492+00	2026-10-29 12:57:33.181503+00	t4f-cabo-verde	Tech4Future-Cabo Verde	country_office	Cabo Verde	t4f-hq	Planned	{}	{"id": "t4f-cabo-verde", "name": "Tech4Future-Cabo Verde", "type": "country_office", "status": "Planned", "country": "Cabo Verde", "parentId": "t4f-hq"}
2026-10-29 12:57:33.185699+00	2026-10-29 12:57:33.18571+00	t4f-cote-divoire	Tech4Future-Côte d’Ivoire	country_office	Côte d’Ivoire	t4f-hq	Planned	{}	{"id": "t4f-cote-divoire", "name": "Tech4Future-Côte d’Ivoire", "type": "country_office", "status": "Planned", "country": "Côte d’Ivoire", "parentId": "t4f-hq"}
2026-10-29 12:57:33.189784+00	2026-10-29 12:57:33.189795+00	t4f-the-gambia	Tech4Future-The Gambia	country_office	The Gambia	t4f-hq	Planned	{}	{"id": "t4f-the-gambia", "name": "Tech4Future-The Gambia", "type": "country_office", "status": "Planned", "country": "The Gambia", "parentId": "t4f-hq"}
2026-10-29 12:57:33.193676+00	2026-10-29 12:57:33.193692+00	t4f-ghana	Tech4Future-Ghana	country_office	Ghana	t4f-hq	Planned	{}	{"id": "t4f-ghana", "name": "Tech4Future-Ghana", "type": "country_office", "status": "Planned", "country": "Ghana", "parentId": "t4f-hq"}
2026-10-29 12:57:33.197482+00	2026-10-29 12:57:33.197493+00	t4f-guinea	Tech4Future-Guinea	country_office	Guinea	t4f-hq	Planned	{}	{"id": "t4f-guinea", "name": "Tech4Future-Guinea", "type": "country_office", "status": "Planned", "country": "Guinea", "parentId": "t4f-hq"}
2026-10-29 12:57:33.200593+00	2026-10-29 12:57:33.200606+00	t4f-guinea-bissau	Tech4Future-Guinea-Bissau	country_office	Guinea-Bissau	t4f-hq	Planned	{}	{"id": "t4f-guinea-bissau", "name": "Tech4Future-Guinea-Bissau", "type": "country_office", "status": "Planned", "country": "Guinea-Bissau", "parentId": "t4f-hq"}
2026-10-29 12:57:33.204052+00	2026-10-29 12:57:33.204063+00	t4f-liberia	Tech4Future-Liberia	country_office	Liberia	t4f-hq	Active	{}	{"id": "t4f-liberia", "name": "Tech4Future-Liberia", "type": "country_office", "status": "Active", "country": "Liberia", "parentId": "t4f-hq"}
2026-10-29 12:57:33.207159+00	2026-10-29 12:57:33.20717+00	t4f-mali	Tech4Future-Mali	country_office	Mali	t4f-hq	Planned	{}	{"id": "t4f-mali", "name": "Tech4Future-Mali", "type": "country_office", "status": "Planned", "country": "Mali", "parentId": "t4f-hq"}
2026-10-29 12:57:33.21113+00	2026-10-29 12:57:33.211144+00	t4f-mauritania	Tech4Future-Mauritania	country_office	Mauritania	t4f-hq	Planned	{}	{"id": "t4f-mauritania", "name": "Tech4Future-Mauritania", "type": "country_office", "status": "Planned", "country": "Mauritania", "parentId": "t4f-hq"}
2026-10-29 12:57:33.214897+00	2026-10-29 12:57:33.21491+00	t4f-niger	Tech4Future-Niger	country_office	Niger	t4f-hq	Planned	{}	{"id": "t4f-niger", "name": "Tech4Future-Niger", "type": "country_office", "status": "Planned", "country": "Niger", "parentId": "t4f-hq"}
2026-10-29 12:57:33.219057+00	2026-10-29 12:57:33.219074+00	t4f-nigeria	Tech4Future-Nigeria	country_office	Nigeria	t4f-hq	Planned	{}	{"id": "t4f-nigeria", "name": "Tech4Future-Nigeria", "type": "country_office", "status": "Planned", "country": "Nigeria", "parentId": "t4f-hq"}
2026-10-29 12:57:33.222253+00	2026-10-29 12:57:33.222263+00	t4f-senegal	Tech4Future-Senegal	country_office	Senegal	t4f-hq	Planned	{}	{"id": "t4f-senegal", "name": "Tech4Future-Senegal", "type": "country_office", "status": "Planned", "country": "Senegal", "parentId": "t4f-hq"}
2026-10-29 12:57:33.225778+00	2026-10-29 12:57:33.225794+00	t4f-sierra-leone	Tech4Future-Sierra Leone	country_office	Sierra Leone	t4f-hq	Planned	{}	{"id": "t4f-sierra-leone", "name": "Tech4Future-Sierra Leone", "type": "country_office", "status": "Planned", "country": "Sierra Leone", "parentId": "t4f-hq"}
2026-10-29 12:57:33.23002+00	2026-10-29 12:57:33.230031+00	t4f-togo	Tech4Future-Togo	country_office	Togo	t4f-hq	Planned	{}	{"id": "t4f-togo", "name": "Tech4Future-Togo", "type": "country_office", "status": "Planned", "country": "Togo", "parentId": "t4f-hq"}
\.


--
-- Data for Name: platform_core_platformprofile; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_platformprofile (id, created_at, updated_at, platform_user_id, system_role, status, must_reset, profile_data, invited_at, last_seen_at, organization_id, position_id, user_id) FROM stdin;
1	2026-10-29 12:57:34.28341+00	2026-10-29 12:57:34.283421+00	t4f-initial-platform-super-admin	platform_super_admin	Active	t	{"bio": "Initial Platform Super Administrator account.", "country": "United States"}	\N	\N	t4f-hq	global-director-executive-leadership	1
\.


--
-- Data for Name: platform_core_platformrecord; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_platformrecord (id, created_at, updated_at, workspace_key, record_type, record_id, organization_id, country, user_ref, status, data) FROM stdin;
\.


--
-- Data for Name: platform_core_position; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_position (created_at, updated_at, id, title, family, "group", reports_to, role_purpose, metadata) FROM stdin;
2026-10-29 12:57:33.235514+00	2026-10-29 12:57:33.235525+00	board-chair	Board Chair	board	Board of Directors	Board of Directors / governing documents	The Board Chair leads the Board as a governing body, protects the boundary between governance and management, and ensures that directors receive the information and meeting discipline needed to exercise fiduciary oversight.	{"Group": "Board of Directors", "Family": "board", "Position": "Board Chair", "Reports To": "Board of Directors / governing documents", "Position ID": "board-chair", "Role Purpose": "The Board Chair leads the Board as a governing body, protects the boundary between governance and management, and ensures that directors receive the information and meeting discipline needed to exercise fiduciary oversight."}
2026-10-29 12:57:33.239219+00	2026-10-29 12:57:33.23923+00	vice-chair	Vice Chair	board	Board of Directors	Board of Directors	The Vice Chair provides governance continuity, supports the Chair and is prepared to lead when the Chair is unavailable, conflicted or formally delegated.	{"Group": "Board of Directors", "Family": "board", "Position": "Vice Chair", "Reports To": "Board of Directors", "Position ID": "vice-chair", "Role Purpose": "The Vice Chair provides governance continuity, supports the Chair and is prepared to lead when the Chair is unavailable, conflicted or formally delegated."}
2026-10-29 12:57:33.24305+00	2026-10-29 12:57:33.243063+00	secretary	Secretary	board	Board of Directors	Board of Directors	The Secretary is the custodian of Tech4Future-Global’s official Board record and ensures that governance decisions are documented, traceable and maintained in an orderly controlled system.	{"Group": "Board of Directors", "Family": "board", "Position": "Secretary", "Reports To": "Board of Directors", "Position ID": "secretary", "Role Purpose": "The Secretary is the custodian of Tech4Future-Global’s official Board record and ensures that governance decisions are documented, traceable and maintained in an orderly controlled system."}
2026-10-29 12:57:33.246855+00	2026-10-29 12:57:33.246866+00	treasurer	Treasurer	board	Board of Directors	Board of Directors	The Treasurer leads the Board’s financial oversight and helps directors understand the organization’s financial position, restrictions, control environment and material financial risks.	{"Group": "Board of Directors", "Family": "board", "Position": "Treasurer", "Reports To": "Board of Directors", "Position ID": "treasurer", "Role Purpose": "The Treasurer leads the Board’s financial oversight and helps directors understand the organization’s financial position, restrictions, control environment and material financial risks."}
2026-10-29 12:57:33.250618+00	2026-10-29 12:57:33.250632+00	director	Director	board	Board of Directors	Board of Directors collectively	A Director shares collective fiduciary responsibility for mission stewardship, strategy, risk oversight, executive accountability and the prudent use of organizational resources.	{"Group": "Board of Directors", "Family": "board", "Position": "Director", "Reports To": "Board of Directors collectively", "Position ID": "director", "Role Purpose": "A Director shares collective fiduciary responsibility for mission stewardship, strategy, risk oversight, executive accountability and the prudent use of organizational resources."}
2026-10-29 12:57:33.253973+00	2026-10-29 12:57:33.253984+00	advisory-board-chair-convener	Advisory Board Chair / Convener	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The Advisory Board Chair / Convener is responsible for coordinating independent expert advice, disciplined advisory meetings and consolidated recommendations. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "Advisory Board Chair / Convener", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "advisory-board-chair-convener", "Role Purpose": "The Advisory Board Chair / Convener is responsible for coordinating independent expert advice, disciplined advisory meetings and consolidated recommendations. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.257274+00	2026-10-29 12:57:33.257285+00	stem-education-curriculum-advisor	STEM Education & Curriculum Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The STEM Education & Curriculum Advisor is responsible for curriculum rigor, pedagogy, credentials, youth learning and instructional quality. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "STEM Education & Curriculum Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "stem-education-curriculum-advisor", "Role Purpose": "The STEM Education & Curriculum Advisor is responsible for curriculum rigor, pedagogy, credentials, youth learning and instructional quality. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.261304+00	2026-10-29 12:57:33.261316+00	cybersecurity-infrastructure-advisor	Cybersecurity & Infrastructure Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The Cybersecurity & Infrastructure Advisor is responsible for cybersecurity, resilient networks, cloud, learning labs and infrastructure standards. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "Cybersecurity & Infrastructure Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "cybersecurity-infrastructure-advisor", "Role Purpose": "The Cybersecurity & Infrastructure Advisor is responsible for cybersecurity, resilient networks, cloud, learning labs and infrastructure standards. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.264787+00	2026-10-29 12:57:33.264798+00	international-development-advisor	International Development Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The International Development Advisor is responsible for localization, development practice, donor expectations and cross-border institutional relationships. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "International Development Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "international-development-advisor", "Role Purpose": "The International Development Advisor is responsible for localization, development practice, donor expectations and cross-border institutional relationships. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.268278+00	2026-10-29 12:57:33.268289+00	cloud-ai-emerging-technology-advisor	Cloud, AI & Emerging Technology Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The Cloud, AI & Emerging Technology Advisor is responsible for future-skills relevance, cloud pathways, responsible AI and emerging-technology roadmaps. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "Cloud, AI & Emerging Technology Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "cloud-ai-emerging-technology-advisor", "Role Purpose": "The Cloud, AI & Emerging Technology Advisor is responsible for future-skills relevance, cloud pathways, responsible AI and emerging-technology roadmaps. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.272356+00	2026-10-29 12:57:33.272367+00	safeguarding-child-protection-advisor	Safeguarding & Child Protection Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The Safeguarding & Child Protection Advisor is responsible for child protection, PSEA, safe programming, referral pathways and survivor-centered practice. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "Safeguarding & Child Protection Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "safeguarding-child-protection-advisor", "Role Purpose": "The Safeguarding & Child Protection Advisor is responsible for child protection, PSEA, safe programming, referral pathways and survivor-centered practice. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.275882+00	2026-10-29 12:57:33.275896+00	finance-audit-nonprofit-controls-advisor	Finance, Audit & Nonprofit Controls Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The Finance, Audit & Nonprofit Controls Advisor is responsible for financial governance, internal controls, audit readiness and restricted-fund stewardship. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "Finance, Audit & Nonprofit Controls Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "finance-audit-nonprofit-controls-advisor", "Role Purpose": "The Finance, Audit & Nonprofit Controls Advisor is responsible for financial governance, internal controls, audit readiness and restricted-fund stewardship. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.279857+00	2026-10-29 12:57:33.279868+00	legal-regulatory-affairs-advisor	Legal & Regulatory Affairs Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The Legal & Regulatory Affairs Advisor is responsible for legal structure, regulatory risk, contracts, country entry and nonprofit governance interfaces. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "Legal & Regulatory Affairs Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "legal-regulatory-affairs-advisor", "Role Purpose": "The Legal & Regulatory Affairs Advisor is responsible for legal structure, regulatory risk, contracts, country entry and nonprofit governance interfaces. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.283312+00	2026-10-29 12:57:33.283323+00	disability-inclusion-accessibility-advisor	Disability Inclusion & Accessibility Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The Disability Inclusion & Accessibility Advisor is responsible for accessible program design, accommodations, universal design and disability inclusion. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "Disability Inclusion & Accessibility Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "disability-inclusion-accessibility-advisor", "Role Purpose": "The Disability Inclusion & Accessibility Advisor is responsible for accessible program design, accommodations, universal design and disability inclusion. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.286817+00	2026-10-29 12:57:33.286828+00	resource-mobilization-partnerships-advisor	Resource Mobilization & Partnerships Advisor	advisory	Advisory Board / Advisory Council	Board of Directors and/or Global Director, Executive Leadership	The Resource Mobilization & Partnerships Advisor is responsible for fundraising strategy, sponsorship, institutional partnerships and responsible external networks. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Advisory Board / Advisory Council", "Family": "advisory", "Position": "Resource Mobilization & Partnerships Advisor", "Reports To": "Board of Directors and/or Global Director, Executive Leadership", "Position ID": "resource-mobilization-partnerships-advisor", "Role Purpose": "The Resource Mobilization & Partnerships Advisor is responsible for fundraising strategy, sponsorship, institutional partnerships and responsible external networks. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.2902+00	2026-10-29 12:57:33.290213+00	global-director-executive-leadership	Global Director, Executive Leadership	global_management	Global Management / C-Level Leadership	Board of Directors	The Global Director, Executive Leadership is responsible for chief executive accountability; organization-wide strategy execution; executive leadership; board reporting; major-risk escalation.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, Executive Leadership", "Reports To": "Board of Directors", "Position ID": "global-director-executive-leadership", "Role Purpose": "The Global Director, Executive Leadership is responsible for chief executive accountability; organization-wide strategy execution; executive leadership; board reporting; major-risk escalation.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.294153+00	2026-10-29 12:57:33.294165+00	global-director-strategy-governance	Global Director, Strategy & Governance	global_management	Global Management / C-Level Leadership	Global Director, Executive Leadership	The Global Director, Strategy & Governance is responsible for strategic planning; board liaison; policy architecture; executive office; enterprise planning and governance coordination.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, Strategy & Governance", "Reports To": "Global Director, Executive Leadership", "Position ID": "global-director-strategy-governance", "Role Purpose": "The Global Director, Strategy & Governance is responsible for strategic planning; board liaison; policy architecture; executive office; enterprise planning and governance coordination.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.297817+00	2026-10-29 12:57:33.297831+00	global-director-finance-administration	Global Director, Finance & Administration	global_management	Global Management / C-Level Leadership	Global Director, Executive Leadership	The Global Director, Finance & Administration is responsible for budgeting; accounting; treasury; restricted funds; financial reporting; audit support; administrative control.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, Finance & Administration", "Reports To": "Global Director, Executive Leadership", "Position ID": "global-director-finance-administration", "Role Purpose": "The Global Director, Finance & Administration is responsible for budgeting; accounting; treasury; restricted funds; financial reporting; audit support; administrative control.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.301497+00	2026-10-29 12:57:33.301509+00	global-director-programs-grants-impact	Global Director, Programs, Grants & Impact	global_management	Global Management / C-Level Leadership	Global Director, Executive Leadership	The Global Director, Programs, Grants & Impact is responsible for program portfolio; grants; curriculum standards; monitoring, evaluation and learning; donor deliverables; impact.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, Programs, Grants & Impact", "Reports To": "Global Director, Executive Leadership", "Position ID": "global-director-programs-grants-impact", "Role Purpose": "The Global Director, Programs, Grants & Impact is responsible for program portfolio; grants; curriculum standards; monitoring, evaluation and learning; donor deliverables; impact.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.30454+00	2026-10-29 12:57:33.30455+00	global-director-operations-country-support	Global Director, Operations & Country Support	global_management	Global Management / C-Level Leadership	Global Director, Executive Leadership	The Global Director, Operations & Country Support is responsible for country performance; logistics; facilities; procurement coordination; operating standards; expansion readiness.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, Operations & Country Support", "Reports To": "Global Director, Executive Leadership", "Position ID": "global-director-operations-country-support", "Role Purpose": "The Global Director, Operations & Country Support is responsible for country performance; logistics; facilities; procurement coordination; operating standards; expansion readiness.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.308106+00	2026-10-29 12:57:33.308117+00	global-director-technology-data-digital-infrastructure	Global Director, Technology, Data & Digital Infrastructure	global_management	Global Management / C-Level Leadership	Global Director, Executive Leadership	The Global Director, Technology, Data & Digital Infrastructure is responsible for technology strategy; systems; infrastructure; cybersecurity; data protection; access control; backup and continuity.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, Technology, Data & Digital Infrastructure", "Reports To": "Global Director, Executive Leadership", "Position ID": "global-director-technology-data-digital-infrastructure", "Role Purpose": "The Global Director, Technology, Data & Digital Infrastructure is responsible for technology strategy; systems; infrastructure; cybersecurity; data protection; access control; backup and continuity.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.312778+00	2026-10-29 12:57:33.312789+00	global-director-partnerships-resource-mobilization-communications	Global Director, Partnerships, Resource Mobilization & Communications	global_management	Global Management / C-Level Leadership	Global Director, Executive Leadership	The Global Director, Partnerships, Resource Mobilization & Communications is responsible for donors; sponsors; partnerships; fundraising; communications; brand stewardship; external relations.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, Partnerships, Resource Mobilization & Communications", "Reports To": "Global Director, Executive Leadership", "Position ID": "global-director-partnerships-resource-mobilization-communications", "Role Purpose": "The Global Director, Partnerships, Resource Mobilization & Communications is responsible for donors; sponsors; partnerships; fundraising; communications; brand stewardship; external relations.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.316598+00	2026-10-29 12:57:33.31661+00	global-director-people-culture-volunteer-engagement	Global Director, People, Culture & Volunteer Engagement	global_management	Global Management / C-Level Leadership	Global Director, Executive Leadership	The Global Director, People, Culture & Volunteer Engagement is responsible for workforce planning; recruitment; performance; learning; culture; volunteer lifecycle; leadership development.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, People, Culture & Volunteer Engagement", "Reports To": "Global Director, Executive Leadership", "Position ID": "global-director-people-culture-volunteer-engagement", "Role Purpose": "The Global Director, People, Culture & Volunteer Engagement is responsible for workforce planning; recruitment; performance; learning; culture; volunteer lifecycle; leadership development.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.320762+00	2026-10-29 12:57:33.320773+00	global-director-compliance-risk-safeguarding	Global Director, Compliance, Risk & Safeguarding	global_management	Global Management / C-Level Leadership	Global Director, Executive Leadership with protected Board access	The Global Director, Compliance, Risk & Safeguarding is responsible for ethics; anti-fraud; safeguarding/psea; risk; investigations; whistleblowing; compliance monitoring and incident escalation.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Management / C-Level Leadership", "Family": "global_management", "Position": "Global Director, Compliance, Risk & Safeguarding", "Reports To": "Global Director, Executive Leadership with protected Board access", "Position ID": "global-director-compliance-risk-safeguarding", "Role Purpose": "The Global Director, Compliance, Risk & Safeguarding is responsible for ethics; anti-fraud; safeguarding/psea; risk; investigations; whistleblowing; compliance monitoring and incident escalation.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.324172+00	2026-10-29 12:57:33.324184+00	global-manager-executive-office	Global Manager, Executive Office	global_employee	Global Functional Employees	Global Director, Strategy & Governance	The Global Manager, Executive Office is responsible for governance integrity, Board effectiveness and proper records. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Manager, Executive Office", "Reports To": "Global Director, Strategy & Governance", "Position ID": "global-manager-executive-office", "Role Purpose": "The Global Manager, Executive Office is responsible for governance integrity, Board effectiveness and proper records. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.328707+00	2026-10-29 12:57:33.328719+00	global-board-policy-liaison	Global Board & Policy Liaison	global_employee	Global Functional Employees	Global Director, Strategy & Governance	The Global Board & Policy Liaison is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Board & Policy Liaison", "Reports To": "Global Director, Strategy & Governance", "Position ID": "global-board-policy-liaison", "Role Purpose": "The Global Board & Policy Liaison is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.333133+00	2026-10-29 12:57:33.333145+00	global-corporate-affairs-coordinator	Global Corporate Affairs Coordinator	global_employee	Global Functional Employees	Global Director, Strategy & Governance	The Global Corporate Affairs Coordinator is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Corporate Affairs Coordinator", "Reports To": "Global Director, Strategy & Governance", "Position ID": "global-corporate-affairs-coordinator", "Role Purpose": "The Global Corporate Affairs Coordinator is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.337163+00	2026-10-29 12:57:33.337175+00	global-finance-manager	Global Finance Manager	global_employee	Global Functional Employees	Global Director, Finance & Administration	The Global Finance Manager is responsible for financial stewardship, accurate records and disciplined controls. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Finance Manager", "Reports To": "Global Director, Finance & Administration", "Position ID": "global-finance-manager", "Role Purpose": "The Global Finance Manager is responsible for financial stewardship, accurate records and disciplined controls. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.340686+00	2026-10-29 12:57:33.340697+00	global-grants-accountant	Global Grants Accountant	global_employee	Global Functional Employees	Global Director, Finance & Administration	The Global Grants Accountant is responsible for financial stewardship, accurate records and disciplined controls. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Grants Accountant", "Reports To": "Global Director, Finance & Administration", "Position ID": "global-grants-accountant", "Role Purpose": "The Global Grants Accountant is responsible for financial stewardship, accurate records and disciplined controls. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.345088+00	2026-10-29 12:57:33.3451+00	global-procurement-asset-officer	Global Procurement & Asset Officer	global_employee	Global Functional Employees	Global Director, Finance & Administration	The Global Procurement & Asset Officer is responsible for financial stewardship, accurate records and disciplined controls. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Procurement & Asset Officer", "Reports To": "Global Director, Finance & Administration", "Position ID": "global-procurement-asset-officer", "Role Purpose": "The Global Procurement & Asset Officer is responsible for financial stewardship, accurate records and disciplined controls. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.349055+00	2026-10-29 12:57:33.349067+00	global-administration-coordinator	Global Administration Coordinator	global_employee	Global Functional Employees	Global Director, Finance & Administration	The Global Administration Coordinator is responsible for organized administration, documentation and responsive internal service. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Administration Coordinator", "Reports To": "Global Director, Finance & Administration", "Position ID": "global-administration-coordinator", "Role Purpose": "The Global Administration Coordinator is responsible for organized administration, documentation and responsive internal service. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.353307+00	2026-10-29 12:57:33.353319+00	global-program-manager	Global Program Manager	global_employee	Global Functional Employees	Global Director, Programs, Grants & Impact	The Global Program Manager is responsible for high-quality program delivery, participant outcomes and grant performance. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Program Manager", "Reports To": "Global Director, Programs, Grants & Impact", "Position ID": "global-program-manager", "Role Purpose": "The Global Program Manager is responsible for high-quality program delivery, participant outcomes and grant performance. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.356556+00	2026-10-29 12:57:33.356568+00	global-grants-donor-compliance-manager	Global Grants & Donor Compliance Manager	global_employee	Global Functional Employees	Global Director, Programs, Grants & Impact	The Global Grants & Donor Compliance Manager is responsible for ethical conduct, safeguarding, risk discipline and prompt incident response. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Grants & Donor Compliance Manager", "Reports To": "Global Director, Programs, Grants & Impact", "Position ID": "global-grants-donor-compliance-manager", "Role Purpose": "The Global Grants & Donor Compliance Manager is responsible for ethical conduct, safeguarding, risk discipline and prompt incident response. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.361018+00	2026-10-29 12:57:33.36103+00	global-monitoring-evaluation-learning-manager	Global Monitoring, Evaluation & Learning Manager	global_employee	Global Functional Employees	Global Director, Programs, Grants & Impact	The Global Monitoring, Evaluation & Learning Manager is responsible for credible evidence, data quality, learning and decision-useful reporting. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Monitoring, Evaluation & Learning Manager", "Reports To": "Global Director, Programs, Grants & Impact", "Position ID": "global-monitoring-evaluation-learning-manager", "Role Purpose": "The Global Monitoring, Evaluation & Learning Manager is responsible for credible evidence, data quality, learning and decision-useful reporting. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.365218+00	2026-10-29 12:57:33.365229+00	global-curriculum-training-quality-manager	Global Curriculum & Training Quality Manager	global_employee	Global Functional Employees	Global Director, Programs, Grants & Impact	The Global Curriculum & Training Quality Manager is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Curriculum & Training Quality Manager", "Reports To": "Global Director, Programs, Grants & Impact", "Position ID": "global-curriculum-training-quality-manager", "Role Purpose": "The Global Curriculum & Training Quality Manager is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.369512+00	2026-10-29 12:57:33.369523+00	global-operations-manager	Global Operations Manager	global_employee	Global Functional Employees	Global Director, Operations & Country Support	The Global Operations Manager is responsible for reliable operations, logistics, country support and execution discipline. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Operations Manager", "Reports To": "Global Director, Operations & Country Support", "Position ID": "global-operations-manager", "Role Purpose": "The Global Operations Manager is responsible for reliable operations, logistics, country support and execution discipline. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.372635+00	2026-10-29 12:57:33.372645+00	global-country-support-manager	Global Country Support Manager	global_employee	Global Functional Employees	Global Director, Operations & Country Support	The Global Country Support Manager is responsible for reliable operations, logistics, country support and execution discipline. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Country Support Manager", "Reports To": "Global Director, Operations & Country Support", "Position ID": "global-country-support-manager", "Role Purpose": "The Global Country Support Manager is responsible for reliable operations, logistics, country support and execution discipline. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.376464+00	2026-10-29 12:57:33.376478+00	global-logistics-facilities-officer	Global Logistics & Facilities Officer	global_employee	Global Functional Employees	Global Director, Operations & Country Support	The Global Logistics & Facilities Officer is responsible for reliable operations, logistics, country support and execution discipline. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Logistics & Facilities Officer", "Reports To": "Global Director, Operations & Country Support", "Position ID": "global-logistics-facilities-officer", "Role Purpose": "The Global Logistics & Facilities Officer is responsible for reliable operations, logistics, country support and execution discipline. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.380827+00	2026-10-29 12:57:33.380839+00	global-it-infrastructure-manager	Global IT Infrastructure Manager	global_employee	Global Functional Employees	Global Director, Technology, Data & Digital Infrastructure	The Global IT Infrastructure Manager is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global IT Infrastructure Manager", "Reports To": "Global Director, Technology, Data & Digital Infrastructure", "Position ID": "global-it-infrastructure-manager", "Role Purpose": "The Global IT Infrastructure Manager is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.384939+00	2026-10-29 12:57:33.38495+00	global-cybersecurity-data-protection-manager	Global Cybersecurity & Data Protection Manager	global_employee	Global Functional Employees	Global Director, Technology, Data & Digital Infrastructure	The Global Cybersecurity & Data Protection Manager is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Cybersecurity & Data Protection Manager", "Reports To": "Global Director, Technology, Data & Digital Infrastructure", "Position ID": "global-cybersecurity-data-protection-manager", "Role Purpose": "The Global Cybersecurity & Data Protection Manager is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.388535+00	2026-10-29 12:57:33.388546+00	global-systems-administrator	Global Systems Administrator	global_employee	Global Functional Employees	Global Director, Technology, Data & Digital Infrastructure	The Global Systems Administrator is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Systems Administrator", "Reports To": "Global Director, Technology, Data & Digital Infrastructure", "Position ID": "global-systems-administrator", "Role Purpose": "The Global Systems Administrator is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.392321+00	2026-10-29 12:57:33.392333+00	global-partnerships-manager	Global Partnerships Manager	global_employee	Global Functional Employees	Global Director, Partnerships, Resource Mobilization & Communications	The Global Partnerships Manager is responsible for mission-aligned partnerships, resource mobilization and trusted external relationships. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Partnerships Manager", "Reports To": "Global Director, Partnerships, Resource Mobilization & Communications", "Position ID": "global-partnerships-manager", "Role Purpose": "The Global Partnerships Manager is responsible for mission-aligned partnerships, resource mobilization and trusted external relationships. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.397201+00	2026-10-29 12:57:33.397214+00	global-fundraising-donor-relations-manager	Global Fundraising & Donor Relations Manager	global_employee	Global Functional Employees	Global Director, Partnerships, Resource Mobilization & Communications	The Global Fundraising & Donor Relations Manager is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Fundraising & Donor Relations Manager", "Reports To": "Global Director, Partnerships, Resource Mobilization & Communications", "Position ID": "global-fundraising-donor-relations-manager", "Role Purpose": "The Global Fundraising & Donor Relations Manager is responsible for secure, reliable and fit-for-purpose technology infrastructure and digital systems. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.401068+00	2026-10-29 12:57:33.40108+00	global-communications-brand-manager	Global Communications & Brand Manager	global_employee	Global Functional Employees	Global Director, Partnerships, Resource Mobilization & Communications	The Global Communications & Brand Manager is responsible for mission-aligned partnerships, resource mobilization and trusted external relationships. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Communications & Brand Manager", "Reports To": "Global Director, Partnerships, Resource Mobilization & Communications", "Position ID": "global-communications-brand-manager", "Role Purpose": "The Global Communications & Brand Manager is responsible for mission-aligned partnerships, resource mobilization and trusted external relationships. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.404864+00	2026-10-29 12:57:33.404876+00	global-hr-talent-manager	Global HR & Talent Manager	global_employee	Global Functional Employees	Global Director, People, Culture & Volunteer Engagement	The Global HR & Talent Manager is responsible for a capable, accountable and supported workforce and volunteer community. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global HR & Talent Manager", "Reports To": "Global Director, People, Culture & Volunteer Engagement", "Position ID": "global-hr-talent-manager", "Role Purpose": "The Global HR & Talent Manager is responsible for a capable, accountable and supported workforce and volunteer community. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.408098+00	2026-10-29 12:57:33.40811+00	global-volunteer-program-manager	Global Volunteer Program Manager	global_employee	Global Functional Employees	Global Director, People, Culture & Volunteer Engagement	The Global Volunteer Program Manager is responsible for high-quality program delivery, participant outcomes and grant performance. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Volunteer Program Manager", "Reports To": "Global Director, People, Culture & Volunteer Engagement", "Position ID": "global-volunteer-program-manager", "Role Purpose": "The Global Volunteer Program Manager is responsible for high-quality program delivery, participant outcomes and grant performance. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.412968+00	2026-10-29 12:57:33.412981+00	global-learning-development-officer	Global Learning & Development Officer	global_employee	Global Functional Employees	Global Director, People, Culture & Volunteer Engagement	The Global Learning & Development Officer is responsible for credible evidence, data quality, learning and decision-useful reporting. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Learning & Development Officer", "Reports To": "Global Director, People, Culture & Volunteer Engagement", "Position ID": "global-learning-development-officer", "Role Purpose": "The Global Learning & Development Officer is responsible for credible evidence, data quality, learning and decision-useful reporting. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.416488+00	2026-10-29 12:57:33.416501+00	global-compliance-manager	Global Compliance Manager	global_employee	Global Functional Employees	Global Director, Compliance, Risk & Safeguarding	The Global Compliance Manager is responsible for ethical conduct, safeguarding, risk discipline and prompt incident response. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Compliance Manager", "Reports To": "Global Director, Compliance, Risk & Safeguarding", "Position ID": "global-compliance-manager", "Role Purpose": "The Global Compliance Manager is responsible for ethical conduct, safeguarding, risk discipline and prompt incident response. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.420482+00	2026-10-29 12:57:33.420494+00	global-safeguarding-lead	Global Safeguarding Lead	global_employee	Global Functional Employees	Global Director, Compliance, Risk & Safeguarding	The Global Safeguarding Lead is responsible for ethical conduct, safeguarding, risk discipline and prompt incident response. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Safeguarding Lead", "Reports To": "Global Director, Compliance, Risk & Safeguarding", "Position ID": "global-safeguarding-lead", "Role Purpose": "The Global Safeguarding Lead is responsible for ethical conduct, safeguarding, risk discipline and prompt incident response. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.423981+00	2026-10-29 12:57:33.423992+00	global-risk-internal-controls-officer	Global Risk & Internal Controls Officer	global_employee	Global Functional Employees	Global Director, Compliance, Risk & Safeguarding	The Global Risk & Internal Controls Officer is responsible for ethical conduct, safeguarding, risk discipline and prompt incident response. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Global Functional Employees", "Family": "global_employee", "Position": "Global Risk & Internal Controls Officer", "Reports To": "Global Director, Compliance, Risk & Safeguarding", "Position ID": "global-risk-internal-controls-officer", "Role Purpose": "The Global Risk & Internal Controls Officer is responsible for ethical conduct, safeguarding, risk discipline and prompt incident response. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.428392+00	2026-10-29 12:57:33.428405+00	regional-coordinator-west-africa	Regional Coordinator, West Africa	regional	West Africa Regional Coordinators	Global Director, Operations & Country Support	The Regional Coordinator, West Africa is responsible for senior regional operating lead; supervises country performance, cross-border planning, operating reviews and expansion coordination.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "West Africa Regional Coordinators", "Family": "regional", "Position": "Regional Coordinator, West Africa", "Reports To": "Global Director, Operations & Country Support", "Position ID": "regional-coordinator-west-africa", "Role Purpose": "The Regional Coordinator, West Africa is responsible for senior regional operating lead; supervises country performance, cross-border planning, operating reviews and expansion coordination.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.432614+00	2026-10-29 12:57:33.432626+00	regional-coordinator-programs-training-quality	Regional Coordinator, Programs & Training Quality	regional	West Africa Regional Coordinators	Regional Coordinator, West Africa; functional line to Global Programs	The Regional Coordinator, Programs & Training Quality is responsible for program standards, curriculum consistency, delivery quality and regional learning.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "West Africa Regional Coordinators", "Family": "regional", "Position": "Regional Coordinator, Programs & Training Quality", "Reports To": "Regional Coordinator, West Africa; functional line to Global Programs", "Position ID": "regional-coordinator-programs-training-quality", "Role Purpose": "The Regional Coordinator, Programs & Training Quality is responsible for program standards, curriculum consistency, delivery quality and regional learning.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.436559+00	2026-10-29 12:57:33.436569+00	regional-coordinator-finance-administration	Regional Coordinator, Finance & Administration	regional	West Africa Regional Coordinators	Regional Coordinator, West Africa; functional line to Global Finance	The Regional Coordinator, Finance & Administration is responsible for country finance review, budgets, controls, reconciliations and administrative discipline.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "West Africa Regional Coordinators", "Family": "regional", "Position": "Regional Coordinator, Finance & Administration", "Reports To": "Regional Coordinator, West Africa; functional line to Global Finance", "Position ID": "regional-coordinator-finance-administration", "Role Purpose": "The Regional Coordinator, Finance & Administration is responsible for country finance review, budgets, controls, reconciliations and administrative discipline.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.440046+00	2026-10-29 12:57:33.440063+00	regional-coordinator-technology-infrastructure	Regional Coordinator, Technology & Infrastructure	regional	West Africa Regional Coordinators	Regional Coordinator, West Africa; functional line to Global Technology	The Regional Coordinator, Technology & Infrastructure is responsible for learning labs, connectivity, device standards, infrastructure quality and technical resilience.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "West Africa Regional Coordinators", "Family": "regional", "Position": "Regional Coordinator, Technology & Infrastructure", "Reports To": "Regional Coordinator, West Africa; functional line to Global Technology", "Position ID": "regional-coordinator-technology-infrastructure", "Role Purpose": "The Regional Coordinator, Technology & Infrastructure is responsible for learning labs, connectivity, device standards, infrastructure quality and technical resilience.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.444407+00	2026-10-29 12:57:33.44442+00	regional-coordinator-partnerships-resource-mobilization	Regional Coordinator, Partnerships & Resource Mobilization	regional	West Africa Regional Coordinators	Regional Coordinator, West Africa; functional line to Global Partnerships	The Regional Coordinator, Partnerships & Resource Mobilization is responsible for regional institutions, universities, government links, donors, sponsors and partnership pipelines.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "West Africa Regional Coordinators", "Family": "regional", "Position": "Regional Coordinator, Partnerships & Resource Mobilization", "Reports To": "Regional Coordinator, West Africa; functional line to Global Partnerships", "Position ID": "regional-coordinator-partnerships-resource-mobilization", "Role Purpose": "The Regional Coordinator, Partnerships & Resource Mobilization is responsible for regional institutions, universities, government links, donors, sponsors and partnership pipelines.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.448483+00	2026-10-29 12:57:33.448495+00	regional-coordinator-monitoring-evaluation-learning	Regional Coordinator, Monitoring, Evaluation & Learning	regional	West Africa Regional Coordinators	Regional Coordinator, West Africa; functional line to Global Programs	The Regional Coordinator, Monitoring, Evaluation & Learning is responsible for common indicators, data quality, impact evidence, learning and regional reporting quality.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "West Africa Regional Coordinators", "Family": "regional", "Position": "Regional Coordinator, Monitoring, Evaluation & Learning", "Reports To": "Regional Coordinator, West Africa; functional line to Global Programs", "Position ID": "regional-coordinator-monitoring-evaluation-learning", "Role Purpose": "The Regional Coordinator, Monitoring, Evaluation & Learning is responsible for common indicators, data quality, impact evidence, learning and regional reporting quality.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.451878+00	2026-10-29 12:57:33.451889+00	regional-coordinator-safeguarding-compliance	Regional Coordinator, Safeguarding & Compliance	regional	West Africa Regional Coordinators	Regional Coordinator, West Africa; protected line to Global Compliance	The Regional Coordinator, Safeguarding & Compliance is responsible for country focal-point support, compliance review, safeguarding assurance and serious-incident escalation.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "West Africa Regional Coordinators", "Family": "regional", "Position": "Regional Coordinator, Safeguarding & Compliance", "Reports To": "Regional Coordinator, West Africa; protected line to Global Compliance", "Position ID": "regional-coordinator-safeguarding-compliance", "Role Purpose": "The Regional Coordinator, Safeguarding & Compliance is responsible for country focal-point support, compliance review, safeguarding assurance and serious-incident escalation.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.455414+00	2026-10-29 12:57:33.455425+00	regional-coordinator-people-volunteer-engagement	Regional Coordinator, People & Volunteer Engagement	regional	West Africa Regional Coordinators	Regional Coordinator, West Africa; functional line to Global People	The Regional Coordinator, People & Volunteer Engagement is responsible for workforce capacity, volunteer coordination, training and cross-country talent pipelines.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "West Africa Regional Coordinators", "Family": "regional", "Position": "Regional Coordinator, People & Volunteer Engagement", "Reports To": "Regional Coordinator, West Africa; functional line to Global People", "Position ID": "regional-coordinator-people-volunteer-engagement", "Role Purpose": "The Regional Coordinator, People & Volunteer Engagement is responsible for workforce capacity, volunteer coordination, training and cross-country talent pipelines.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.458821+00	2026-10-29 12:57:33.458833+00	country-director	Country Director	country	Country Office Employees	Regional Coordinator, West Africa	The Country Director is responsible for national leadership, stakeholder management, approved operations, local legal compliance and monthly accountability.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Country Director", "Reports To": "Regional Coordinator, West Africa", "Position ID": "country-director", "Role Purpose": "The Country Director is responsible for national leadership, stakeholder management, approved operations, local legal compliance and monthly accountability.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.463249+00	2026-10-29 12:57:33.46326+00	deputy-country-director-country-operations-manager	Deputy Country Director / Country Operations Manager	country	Country Office Employees	Country Director	The Deputy Country Director / Country Operations Manager is responsible for internal operations, staffing coordination, administration, facilities, continuity and support to the country director.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Deputy Country Director / Country Operations Manager", "Reports To": "Country Director", "Position ID": "deputy-country-director-country-operations-manager", "Role Purpose": "The Deputy Country Director / Country Operations Manager is responsible for internal operations, staffing coordination, administration, facilities, continuity and support to the country director.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.466634+00	2026-10-29 12:57:33.466645+00	country-program-manager	Country Program Manager	country	Country Office Employees	Country Director	The Country Program Manager is responsible for program portfolio, workplans, curriculum implementation, grant outputs and program-team supervision.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Country Program Manager", "Reports To": "Country Director", "Position ID": "country-program-manager", "Role Purpose": "The Country Program Manager is responsible for program portfolio, workplans, curriculum implementation, grant outputs and program-team supervision.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.470384+00	2026-10-29 12:57:33.470395+00	country-finance-administration-manager	Country Finance & Administration Manager	country	Country Office Employees	Country Director; functional line to Regional Finance	The Country Finance & Administration Manager is responsible for country budgeting, financial documentation, cash/advance controls, payroll inputs, reconciliations and administration.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Country Finance & Administration Manager", "Reports To": "Country Director; functional line to Regional Finance", "Position ID": "country-finance-administration-manager", "Role Purpose": "The Country Finance & Administration Manager is responsible for country budgeting, financial documentation, cash/advance controls, payroll inputs, reconciliations and administration.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.47338+00	2026-10-29 12:57:33.47339+00	country-technology-infrastructure-manager	Country Technology & Infrastructure Manager	country	Country Office Employees	Country Director; functional line to Regional Technology	The Country Technology & Infrastructure Manager is responsible for labs, connectivity, devices, infrastructure, it support, access controls and local backup.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Country Technology & Infrastructure Manager", "Reports To": "Country Director; functional line to Regional Technology", "Position ID": "country-technology-infrastructure-manager", "Role Purpose": "The Country Technology & Infrastructure Manager is responsible for labs, connectivity, devices, infrastructure, it support, access controls and local backup.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.477115+00	2026-10-29 12:57:33.477127+00	country-partnerships-outreach-manager	Country Partnerships & Outreach Manager	country	Country Office Employees	Country Director	The Country Partnerships & Outreach Manager is responsible for government, community, university, ngo and private-sector relationships; sponsorship support and outreach.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Country Partnerships & Outreach Manager", "Reports To": "Country Director", "Position ID": "country-partnerships-outreach-manager", "Role Purpose": "The Country Partnerships & Outreach Manager is responsible for government, community, university, ngo and private-sector relationships; sponsorship support and outreach.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.481102+00	2026-10-29 12:57:33.481114+00	country-monitoring-evaluation-learning-officer	Country Monitoring, Evaluation & Learning Officer	country	Country Office Employees	Country Program Manager / Country Director	The Country Monitoring, Evaluation & Learning Officer is responsible for indicators, data quality, participant evidence, learning, reporting and outcome tracking.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Country Monitoring, Evaluation & Learning Officer", "Reports To": "Country Program Manager / Country Director", "Position ID": "country-monitoring-evaluation-learning-officer", "Role Purpose": "The Country Monitoring, Evaluation & Learning Officer is responsible for indicators, data quality, participant evidence, learning, reporting and outcome tracking.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.484535+00	2026-10-29 12:57:33.484545+00	country-safeguarding-compliance-officer	Country Safeguarding & Compliance Officer	country	Country Office Employees	Country Director; protected line to Regional/Global Compliance	The Country Safeguarding & Compliance Officer is responsible for safeguarding/psea, ethics, incident response, training, due diligence and compliance registers.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Country Safeguarding & Compliance Officer", "Reports To": "Country Director; protected line to Regional/Global Compliance", "Position ID": "country-safeguarding-compliance-officer", "Role Purpose": "The Country Safeguarding & Compliance Officer is responsible for safeguarding/psea, ethics, incident response, training, due diligence and compliance registers.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.487703+00	2026-10-29 12:57:33.487713+00	country-hr-volunteer-coordinator	Country HR & Volunteer Coordinator	country	Country Office Employees	Country Director	The Country HR & Volunteer Coordinator is responsible for recruitment administration, onboarding, personnel records, volunteer screening, rosters, training and offboarding.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Country HR & Volunteer Coordinator", "Reports To": "Country Director", "Position ID": "country-hr-volunteer-coordinator", "Role Purpose": "The Country HR & Volunteer Coordinator is responsible for recruitment administration, onboarding, personnel records, volunteer screening, rosters, training and offboarding.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.491172+00	2026-10-29 12:57:33.491182+00	program-project-coordinator	Program / Project Coordinator	country	Country Office Employees	Country Program Manager	The Program / Project Coordinator is responsible for activity delivery, field coordination, participant protection, outputs, evidence and routine reporting.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Program / Project Coordinator", "Reports To": "Country Program Manager", "Position ID": "program-project-coordinator", "Role Purpose": "The Program / Project Coordinator is responsible for activity delivery, field coordination, participant protection, outputs, evidence and routine reporting.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.495337+00	2026-10-29 12:57:33.495348+00	technical-trainer-instructor	Technical Trainer / Instructor	country	Country Office Employees	Country Program Manager	The Technical Trainer / Instructor is responsible for teaching, mentoring, practical labs, assessment, certification support and learner progression.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Technical Trainer / Instructor", "Reports To": "Country Program Manager", "Position ID": "technical-trainer-instructor", "Role Purpose": "The Technical Trainer / Instructor is responsible for teaching, mentoring, practical labs, assessment, certification support and learner progression.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.499238+00	2026-10-29 12:57:33.49925+00	lab-technician	Lab Technician	country	Country Office Employees	Country Technology & Infrastructure Manager	The Lab Technician is responsible for lab readiness, device maintenance, equipment control, troubleshooting and safe technical operations.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Lab Technician", "Reports To": "Country Technology & Infrastructure Manager", "Position ID": "lab-technician", "Role Purpose": "The Lab Technician is responsible for lab readiness, device maintenance, equipment control, troubleshooting and safe technical operations.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.503011+00	2026-10-29 12:57:33.503023+00	it-support-specialist	IT Support Specialist	country	Country Office Employees	Country Technology & Infrastructure Manager	The IT Support Specialist is responsible for user support, endpoint administration, connectivity, access support and issue documentation.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "IT Support Specialist", "Reports To": "Country Technology & Infrastructure Manager", "Position ID": "it-support-specialist", "Role Purpose": "The IT Support Specialist is responsible for user support, endpoint administration, connectivity, access support and issue documentation.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.507053+00	2026-10-29 12:57:33.507065+00	community-mobilizer	Community Mobilizer	country	Country Office Employees	Country Partnerships / Program Manager	The Community Mobilizer is responsible for community outreach, participant mobilization, registration support, follow-up and local engagement.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Community Mobilizer", "Reports To": "Country Partnerships / Program Manager", "Position ID": "community-mobilizer", "Role Purpose": "The Community Mobilizer is responsible for community outreach, participant mobilization, registration support, follow-up and local engagement.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.511889+00	2026-10-29 12:57:33.511902+00	finance-administration-assistant	Finance & Administration Assistant	country	Country Office Employees	Country Finance & Administration Manager	The Finance & Administration Assistant is responsible for documentation, filing, transaction support, administrative coordination and controlled record keeping.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Finance & Administration Assistant", "Reports To": "Country Finance & Administration Manager", "Position ID": "finance-administration-assistant", "Role Purpose": "The Finance & Administration Assistant is responsible for documentation, filing, transaction support, administrative coordination and controlled record keeping.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.516558+00	2026-10-29 12:57:33.516574+00	logistics-procurement-support-officer	Logistics & Procurement Support Officer	country	Country Office Employees	Country Operations / Finance & Administration	The Logistics & Procurement Support Officer is responsible for purchasing support, inventory movement, logistics, vendor documentation and delivery evidence.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Country Office Employees", "Family": "country", "Position": "Logistics & Procurement Support Officer", "Reports To": "Country Operations / Finance & Administration", "Position ID": "logistics-procurement-support-officer", "Role Purpose": "The Logistics & Procurement Support Officer is responsible for purchasing support, inventory movement, logistics, vendor documentation and delivery evidence.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.521385+00	2026-10-29 12:57:33.521398+00	volunteer-lead-global-mentorship	Volunteer Lead, Global Mentorship	volunteer	Volunteer Service Positions	Global Volunteer Program Manager	The Volunteer Lead, Global Mentorship is responsible for coordinates global mentorship volunteers, matching, schedules, support and quality.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Volunteer Lead, Global Mentorship", "Reports To": "Global Volunteer Program Manager", "Position ID": "volunteer-lead-global-mentorship", "Role Purpose": "The Volunteer Lead, Global Mentorship is responsible for coordinates global mentorship volunteers, matching, schedules, support and quality.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.525726+00	2026-10-29 12:57:33.525739+00	strategic-ambassador-global-partnerships	Strategic Ambassador, Global Partnerships	volunteer	Volunteer Service Positions	Global Partnerships Manager	The Strategic Ambassador, Global Partnerships is responsible for represents the mission in approved forums and helps open responsible partnership and resource-mobilization opportunities.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Strategic Ambassador, Global Partnerships", "Reports To": "Global Partnerships Manager", "Position ID": "strategic-ambassador-global-partnerships", "Role Purpose": "The Strategic Ambassador, Global Partnerships is responsible for represents the mission in approved forums and helps open responsible partnership and resource-mobilization opportunities.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.529946+00	2026-10-29 12:57:33.529958+00	county-volunteer-coordinator	County Volunteer Coordinator	volunteer	Volunteer Service Positions	Country HR & Volunteer Coordinator / Country leadership	The County Volunteer Coordinator is responsible for coordinates local volunteer rosters, assignments, schedules and community activity support within an approved county or locality.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "County Volunteer Coordinator", "Reports To": "Country HR & Volunteer Coordinator / Country leadership", "Position ID": "county-volunteer-coordinator", "Role Purpose": "The County Volunteer Coordinator is responsible for coordinates local volunteer rosters, assignments, schedules and community activity support within an approved county or locality.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.534161+00	2026-10-29 12:57:33.534173+00	training-volunteer	Training Volunteer	volunteer	Volunteer Service Positions	Program / Project Coordinator	The Training Volunteer is responsible for assists supervised learning sessions, learner support, demonstrations and practical activities.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Training Volunteer", "Reports To": "Program / Project Coordinator", "Position ID": "training-volunteer", "Role Purpose": "The Training Volunteer is responsible for assists supervised learning sessions, learner support, demonstrations and practical activities.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.539357+00	2026-10-29 12:57:33.53937+00	digital-literacy-mentor	Digital Literacy Mentor	volunteer	Volunteer Service Positions	Program / Project Coordinator	The Digital Literacy Mentor is responsible for supports foundational computer skills, safe internet use, productivity tools and learner confidence.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Digital Literacy Mentor", "Reports To": "Program / Project Coordinator", "Position ID": "digital-literacy-mentor", "Role Purpose": "The Digital Literacy Mentor is responsible for supports foundational computer skills, safe internet use, productivity tools and learner confidence.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.54338+00	2026-10-29 12:57:33.543395+00	regional-it-mentor	Regional IT Mentor	volunteer	Volunteer Service Positions	Regional Technology / Country Technology lead	The Regional IT Mentor is responsible for provides structured technical mentoring, career guidance and specialist support across approved country programs.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Regional IT Mentor", "Reports To": "Regional Technology / Country Technology lead", "Position ID": "regional-it-mentor", "Role Purpose": "The Regional IT Mentor is responsible for provides structured technical mentoring, career guidance and specialist support across approved country programs.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.547953+00	2026-10-29 12:57:33.547966+00	youth-tech-club-volunteer	Youth Tech Club Volunteer	volunteer	Volunteer Service Positions	Program / Project Coordinator	The Youth Tech Club Volunteer is responsible for supports supervised youth coding, robotics, digital creativity and club activities.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Youth Tech Club Volunteer", "Reports To": "Program / Project Coordinator", "Position ID": "youth-tech-club-volunteer", "Role Purpose": "The Youth Tech Club Volunteer is responsible for supports supervised youth coding, robotics, digital creativity and club activities.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.552423+00	2026-10-29 12:57:33.552435+00	women-girls-in-tech-volunteer	Women & Girls in Tech Volunteer	volunteer	Volunteer Service Positions	Program / Project Coordinator	The Women & Girls in Tech Volunteer is responsible for supports inclusive outreach, mentoring, retention and safe participation for women and girls.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Women & Girls in Tech Volunteer", "Reports To": "Program / Project Coordinator", "Position ID": "women-girls-in-tech-volunteer", "Role Purpose": "The Women & Girls in Tech Volunteer is responsible for supports inclusive outreach, mentoring, retention and safe participation for women and girls.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.555853+00	2026-10-29 12:57:33.555864+00	disability-inclusion-volunteer	Disability Inclusion Volunteer	volunteer	Volunteer Service Positions	Program / Project Coordinator / Inclusion focal point	The Disability Inclusion Volunteer is responsible for supports accessible participation, accommodations, inclusion feedback and barrier reduction.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Disability Inclusion Volunteer", "Reports To": "Program / Project Coordinator / Inclusion focal point", "Position ID": "disability-inclusion-volunteer", "Role Purpose": "The Disability Inclusion Volunteer is responsible for supports accessible participation, accommodations, inclusion feedback and barrier reduction.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.559704+00	2026-10-29 12:57:33.559716+00	lab-support-volunteer	Lab Support Volunteer	volunteer	Volunteer Service Positions	Lab Technician / Country Technology Manager	The Lab Support Volunteer is responsible for assists equipment setup, lab readiness, safe use and supervised learner support.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Lab Support Volunteer", "Reports To": "Lab Technician / Country Technology Manager", "Position ID": "lab-support-volunteer", "Role Purpose": "The Lab Support Volunteer is responsible for assists equipment setup, lab readiness, safe use and supervised learner support.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.563674+00	2026-10-29 12:57:33.56369+00	school-support-volunteer	School Support Volunteer	volunteer	Volunteer Service Positions	Program / Project Coordinator	The School Support Volunteer is responsible for supports school-based activities, learner registration, coordination with educators and activity logistics.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "School Support Volunteer", "Reports To": "Program / Project Coordinator", "Position ID": "school-support-volunteer", "Role Purpose": "The School Support Volunteer is responsible for supports school-based activities, learner registration, coordination with educators and activity logistics.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.568319+00	2026-10-29 12:57:33.56833+00	university-hub-leader	University Hub Leader	volunteer	Volunteer Service Positions	Country Program / Partnerships Manager	The University Hub Leader is responsible for coordinates approved campus-based peer learning, outreach, mentorship and innovation activities.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "University Hub Leader", "Reports To": "Country Program / Partnerships Manager", "Position ID": "university-hub-leader", "Role Purpose": "The University Hub Leader is responsible for coordinates approved campus-based peer learning, outreach, mentorship and innovation activities.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.572167+00	2026-10-29 12:57:33.572178+00	community-support-volunteer	Community Support Volunteer	volunteer	Volunteer Service Positions	Community Mobilizer / Program Coordinator	The Community Support Volunteer is responsible for supports registrations, events, follow-up, community information and local activity logistics.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Community Support Volunteer", "Reports To": "Community Mobilizer / Program Coordinator", "Position ID": "community-support-volunteer", "Role Purpose": "The Community Support Volunteer is responsible for supports registrations, events, follow-up, community information and local activity logistics.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.575922+00	2026-10-29 12:57:33.575938+00	community-leader-liaison-volunteer	Community Leader / Liaison Volunteer	volunteer	Volunteer Service Positions	Country Partnerships & Outreach Manager	The Community Leader / Liaison Volunteer is responsible for provides local relationship support, feedback, community introductions and trusted communication.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Community Leader / Liaison Volunteer", "Reports To": "Country Partnerships & Outreach Manager", "Position ID": "community-leader-liaison-volunteer", "Role Purpose": "The Community Leader / Liaison Volunteer is responsible for provides local relationship support, feedback, community introductions and trusted communication.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.579539+00	2026-10-29 12:57:33.579551+00	digital-inclusion-advocate	Digital Inclusion Advocate	volunteer	Volunteer Service Positions	Country Partnerships & Outreach Manager	The Digital Inclusion Advocate is responsible for promotes responsible digital inclusion, access and community awareness using approved messaging.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Digital Inclusion Advocate", "Reports To": "Country Partnerships & Outreach Manager", "Position ID": "digital-inclusion-advocate", "Role Purpose": "The Digital Inclusion Advocate is responsible for promotes responsible digital inclusion, access and community awareness using approved messaging.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.584041+00	2026-10-29 12:57:33.584057+00	media-creative-volunteer	Media & Creative Volunteer	volunteer	Volunteer Service Positions	Global/Regional/Country Communications lead	The Media & Creative Volunteer is responsible for creates or supports approved communications, stories, photography, design and event media while protecting consent and privacy.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Media & Creative Volunteer", "Reports To": "Global/Regional/Country Communications lead", "Position ID": "media-creative-volunteer", "Role Purpose": "The Media & Creative Volunteer is responsible for creates or supports approved communications, stories, photography, design and event media while protecting consent and privacy.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.587588+00	2026-10-29 12:57:33.587599+00	stem-professional-volunteer	STEM Professional Volunteer	volunteer	Volunteer Service Positions	Program Manager / Curriculum lead	The STEM Professional Volunteer is responsible for contributes expert demonstrations, mentoring, curriculum input and technical career exposure.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "STEM Professional Volunteer", "Reports To": "Program Manager / Curriculum lead", "Position ID": "stem-professional-volunteer", "Role Purpose": "The STEM Professional Volunteer is responsible for contributes expert demonstrations, mentoring, curriculum input and technical career exposure.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.591117+00	2026-10-29 12:57:33.591128+00	ngo-professional-volunteer	NGO Professional Volunteer	volunteer	Volunteer Service Positions	Country Director / relevant functional lead	The NGO Professional Volunteer is responsible for contributes pro bono nonprofit, program, governance, operations or partnership expertise within an agreed scope.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "NGO Professional Volunteer", "Reports To": "Country Director / relevant functional lead", "Position ID": "ngo-professional-volunteer", "Role Purpose": "The NGO Professional Volunteer is responsible for contributes pro bono nonprofit, program, governance, operations or partnership expertise within an agreed scope.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
2026-10-29 12:57:33.594959+00	2026-10-29 12:57:33.594971+00	resource-mobilization-volunteer	Resource Mobilization Volunteer	volunteer	Volunteer Service Positions	Partnerships / Fundraising lead	The Resource Mobilization Volunteer is responsible for supports prospect research, introductions, events and donor/sponsor engagement without independent solicitation authority.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope.	{"Group": "Volunteer Service Positions", "Family": "volunteer", "Position": "Resource Mobilization Volunteer", "Reports To": "Partnerships / Fundraising lead", "Position ID": "resource-mobilization-volunteer", "Role Purpose": "The Resource Mobilization Volunteer is responsible for supports prospect research, introductions, events and donor/sponsor engagement without independent solicitation authority.. The position turns organizational direction into clear, documented action and remains accountable for quality, integrity and timely escalation within its scope."}
\.


--
-- Data for Name: platform_core_workspacestate; Type: TABLE DATA; Schema: public; Owner: t4f_app
--

COPY public.platform_core_workspacestate (created_at, updated_at, key, revision, state, last_saved_by_id) FROM stdin;
2026-10-29 12:57:34.288582+00	2026-10-29 12:57:34.288592+00	t4f-global	1	{"audit": [], "users": [{"id": "t4f-initial-platform-super-admin", "name": "Tech4Future-Global Super Administrator", "email": "admin@t4f-global.org", "orgId": "t4f-hq", "status": "Active", "profile": {"country": "United States"}, "mustReset": true, "positionId": "global-director-executive-leadership", "systemRole": "platform_super_admin"}], "grants": [], "ledger": [], "aiFiles": [], "budgets": [], "reports": [], "emailLog": [], "programs": [], "projects": [], "requests": [], "settings": {"backend": "django-fastapi", "version": "13.0", "controlledLibrarySource": "T4FG-LIB-004 v2.0"}, "aiHistory": [], "documents": [{"id": "T4FG-GOV-001", "name": "Tech4Future-Global Bylaws", "type": "Bylaws", "owner": "Board Secretary / Governance", "number": "01", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + legal/event", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Required legal review", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-002", "name": "Advisory Council Charter, Appointment, Acceptance, and Onboarding Package", "type": "Package", "owner": "Board Secretary / Governance", "number": "02", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial + event", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country adaptation conditional", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-003", "name": "Annual Board Compliance Checklist and Governance Certification Workbook", "type": "Workbook", "owner": "Board Secretary / Compliance", "number": "03", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Global; country evidence required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-004", "name": "Board Authority, Fiduciary Duties, and Reserved Decisions Policy", "type": "Policy", "owner": "Board Chair / Secretary", "number": "04", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "No weakening; legal review", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-005", "name": "Board, Management, and Country-Office Approval Limits Policy", "type": "Policy", "owner": "CFO / Governance", "number": "05", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country currency schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-006", "name": "Board Meetings, Resolutions, and Official Records Manual", "type": "Manual", "owner": "Board Secretary", "number": "06", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial + law", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Local records supplement conditional", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-007", "name": "Board Member Appointment, Acceptance, and Onboarding Package", "type": "Package", "owner": "Board Secretary", "number": "07", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Global form; local law as needed", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-008", "name": "C-Level Executive and Department Head Appointment, Authority, Performance, and Onboarding Package", "type": "Package", "owner": "Executive Director / HR", "number": "08", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country employment supplement required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-009", "name": "Country-Office Governance and Delegated Authority Manual", "type": "Manual", "owner": "Executive Director / Governance", "number": "09", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-010", "name": "Country Advisory Council Charter", "type": "Charter", "owner": "Country Director / Governance", "number": "10", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country customization required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-011", "name": "Country Director Appointment, Authority, Performance, and Onboarding Package", "type": "Package", "owner": "Executive Director / HR", "number": "11", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country customization required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-012", "name": "Executive Director Authority, Performance, Accountability, and Succession Policy", "type": "Policy", "owner": "Board Chair / HR Committee", "number": "12", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Global core; U.S. legal review", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-013", "name": "Governance Registers and Board-Meeting Templates Toolkit", "type": "Toolkit", "owner": "Board Secretary", "number": "13", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director under Board policy", "countryApplicability": "Global forms; country fields as needed", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-GOV-014", "name": "Officer and Committee Responsibilities Charter Manual", "type": "Manual", "owner": "Board Secretary", "number": "14", "status": "Awaiting Upload", "version": "", "category": "Governance, Board & Delegated Authority", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "GOV", "effectiveDate": "", "controlPurpose": "Constitutional authority, Board practice, leadership accountability and country delegation.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Global core; committee schedules", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-001", "name": "Annual Budgeting and Budget Revisions Policy", "type": "Policy", "owner": "CFO / Global Finance", "number": "15", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country budget/calendar required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-002", "name": "Anti-Fraud, Anti-Bribery, and Financial Misconduct Controls Policy", "type": "Policy", "owner": "Compliance / CFO", "number": "16", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country law/reporting required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-003", "name": "Asset Registers, Audits, Record Retention, and Financial Reporting Manual", "type": "Manual", "owner": "CFO / Internal Audit", "number": "17", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country tax/accounting schedule", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-004", "name": "Banking, Payment, Procurement, and Reimbursement Controls Manual", "type": "Manual", "owner": "CFO / Procurement", "number": "18", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country banking/tax required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-005", "name": "Cash Advances and Petty-Cash Management Policy", "type": "Policy", "owner": "CFO / Country Finance", "number": "19", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country limits/currency required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-006", "name": "Cross-Border Funds, Foreign Exchange, and Banking Policy", "type": "Policy", "owner": "CFO / Treasury", "number": "20", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + event", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country FX/banking required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-007", "name": "Donor, Sponsor, and Partner Income Procedures Manual", "type": "Manual", "owner": "CFO / Fundraising", "number": "21", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director under Board policy", "countryApplicability": "Country receipt/tax required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-008", "name": "Financial Approval Matrix, Payment Forms, Reconciliation Templates, and Control Registers Toolkit", "type": "Toolkit", "owner": "CFO / Governance", "number": "22", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board for limits; ED for forms", "countryApplicability": "Country currency/forms required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-009", "name": "Financial Roles and Segregation of Duties Policy", "type": "Policy", "owner": "CFO / HR", "number": "23", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country staffing matrix required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-010", "name": "Fiscal-Sponsor Reporting and Reconciliation Manual", "type": "Manual", "owner": "CFO / Grants", "number": "24", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + agreement", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "FMW schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-011", "name": "Grant Expenditure Eligibility and Cost-Allowability Policy", "type": "Policy", "owner": "CFO / Grants", "number": "25", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + award", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Donor/country supplement required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-012", "name": "Payroll and Consultant-Payment Controls Policy", "type": "Policy", "owner": "CFO / HR", "number": "26", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country payroll/tax required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-FIN-013", "name": "Restricted-Fund Accounting and Donor-Condition Tracking Manual", "type": "Manual", "owner": "CFO / Grants", "number": "27", "status": "Awaiting Upload", "version": "", "category": "Financial Governance & Controls", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + award", "sensitivity": "Controlled", "categoryCode": "FIN", "effectiveDate": "", "controlPurpose": "Budgeting, custody of funds, payment integrity, restricted funding and fiscal accountability.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country/donor coding required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-001", "name": "Child and Vulnerable-Adult Safeguarding Policy", "type": "Policy", "owner": "Safeguarding Lead / HR", "number": "28", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country referral/law required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-002", "name": "Complaints, Grievances, and Case-Management Procedures Manual", "type": "Manual", "owner": "Compliance / HR / Safeguarding", "number": "29", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director under Board policy", "countryApplicability": "Country channels/law required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-003", "name": "Employee Appointment, Onboarding, Performance, Timekeeping, and Offboarding Package", "type": "Package", "owner": "HR Director", "number": "30", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director", "countryApplicability": "Country employment package required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-004", "name": "Ethics, Whistleblowing, and Non-Retaliation Policy", "type": "Policy", "owner": "Compliance / Board Secretary", "number": "31", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country reporting/legal required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-005", "name": "Health, Safety, Security, and Workplace Incident Management Policy", "type": "Policy", "owner": "HR / Security", "number": "32", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country workplace law required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-006", "name": "Human Resources and Personnel Policy Manual", "type": "Manual", "owner": "HR Director", "number": "33", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country handbook required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-007", "name": "Prevention of Sexual Exploitation, Abuse, and Harassment Policy", "type": "Policy", "owner": "Safeguarding Lead / HR", "number": "34", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country referral/law required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-008", "name": "Succession Planning, Leadership Continuity, and Executive Transition Manual", "type": "Manual", "owner": "Board / HR", "number": "35", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country succession schedule", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-009", "name": "Travel, Security, and Duty-of-Care Policy", "type": "Policy", "owner": "Security / HR / Programs", "number": "36", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + threat", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country travel/security plan", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PEO-010", "name": "Volunteer, Intern, and Community-Service Management Policy", "type": "Policy", "owner": "HR / Volunteer Lead", "number": "37", "status": "Awaiting Upload", "version": "", "category": "People, Conduct & Safeguarding", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PEO", "effectiveDate": "", "controlPurpose": "Employment, ethical conduct, safeguarding, workplace protection and duty of care.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country labor/safeguarding required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-001", "name": "Business Continuity, Disaster Recovery, and Emergency Management Plan", "type": "Plan", "owner": "Risk / IT / Operations", "number": "38", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + exercise", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country continuity annex required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-002", "name": "Data Protection, Privacy, and Confidentiality Policy", "type": "Policy", "owner": "Privacy / Legal / IT", "number": "39", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + law", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country privacy schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-003", "name": "Enterprise Risk Management, Risk Appetite, and Organizational Assurance Framework", "type": "Framework", "owner": "Risk Lead / Executive Director", "number": "40", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country risk register required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-004", "name": "Information Security, Cybersecurity, and Acceptable-Use Policy", "type": "Policy", "owner": "CISO / IT", "number": "41", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + incident", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country systems annex required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-005", "name": "Insurance, Risk Financing, and Claims Management Policy", "type": "Policy", "owner": "CFO / Risk", "number": "42", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country coverage schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-006", "name": "Internal Audit Charter and Compliance Monitoring Manual", "type": "Manual", "owner": "Internal Audit / Compliance", "number": "43", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country audit universe required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-007", "name": "Legal Compliance, Regulatory Filings, Licenses, and Statutory Reporting Manual", "type": "Manual", "owner": "Legal / Compliance", "number": "44", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + law", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country legal register required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-008", "name": "Records Classification and Detailed Retention Schedule", "type": "Schedule", "owner": "Records Officer / Legal", "number": "45", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + law", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country retention schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-009", "name": "Risk Management and Serious-Incident Escalation Manual", "type": "Manual", "owner": "Risk / Compliance", "number": "46", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country contacts/escalation required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-RISK-010", "name": "Sanctions, Counterterrorism, and Restricted-Party Screening Policy", "type": "Policy", "owner": "Compliance / Legal", "number": "47", "status": "Awaiting Upload", "version": "", "category": "Risk, Legal, Assurance & Security", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + list/law", "sensitivity": "Controlled", "categoryCode": "RISK", "effectiveDate": "", "controlPurpose": "Enterprise risk, legal compliance, assurance, privacy, cybersecurity and organizational resilience.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country law/list schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PROG-001", "name": "Beneficiary Selection and Assistance-Distribution Policy", "type": "Policy", "owner": "Programs / MEAL / Safeguarding", "number": "48", "status": "Awaiting Upload", "version": "", "category": "Programs, Grants & Partnerships", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PROG", "effectiveDate": "", "controlPurpose": "Program quality, grants, partners, beneficiaries, fundraising and external engagement.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country program criteria required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PROG-002", "name": "Communications, Branding, Media, Publications, and Public-Representation Policy", "type": "Policy", "owner": "Communications Director", "number": "49", "status": "Awaiting Upload", "version": "", "category": "Programs, Grants & Partnerships", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial + event", "sensitivity": "Controlled", "categoryCode": "PROG", "effectiveDate": "", "controlPurpose": "Program quality, grants, partners, beneficiaries, fundraising and external engagement.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country spokesperson schedule", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PROG-003", "name": "Fundraising, Resource Mobilization, Sponsorship, and Ethical Donor Engagement Policy", "type": "Policy", "owner": "Fundraising / Compliance", "number": "50", "status": "Awaiting Upload", "version": "", "category": "Programs, Grants & Partnerships", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PROG", "effectiveDate": "", "controlPurpose": "Program quality, grants, partners, beneficiaries, fundraising and external engagement.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country fundraising law required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PROG-004", "name": "Government Relations, Advocacy, and Public Policy Engagement Policy", "type": "Policy", "owner": "Executive Director / Legal", "number": "51", "status": "Awaiting Upload", "version": "", "category": "Programs, Grants & Partnerships", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + election/law", "sensitivity": "Controlled", "categoryCode": "PROG", "effectiveDate": "", "controlPurpose": "Program quality, grants, partners, beneficiaries, fundraising and external engagement.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country lobbying/political law required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PROG-005", "name": "Grant Application, Acceptance, and Award-Management Procedures", "type": "Procedures", "owner": "Grants Director / CFO", "number": "52", "status": "Awaiting Upload", "version": "", "category": "Programs, Grants & Partnerships", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + award", "sensitivity": "Controlled", "categoryCode": "PROG", "effectiveDate": "", "controlPurpose": "Program quality, grants, partners, beneficiaries, fundraising and external engagement.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director under Board policy", "countryApplicability": "Donor/country workflow required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PROG-006", "name": "Partnerships, Subawards, Consortiums, and Third-Party Due-Diligence Manual", "type": "Manual", "owner": "Programs / Grants / Compliance", "number": "53", "status": "Awaiting Upload", "version": "", "category": "Programs, Grants & Partnerships", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PROG", "effectiveDate": "", "controlPurpose": "Program quality, grants, partners, beneficiaries, fundraising and external engagement.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country partner schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PROG-007", "name": "Program and Project Management, Monitoring, Evaluation, Accountability, and Learning Manual", "type": "Manual", "owner": "Programs / MEAL", "number": "54", "status": "Awaiting Upload", "version": "", "category": "Programs, Grants & Partnerships", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "PROG", "effectiveDate": "", "controlPurpose": "Program quality, grants, partners, beneficiaries, fundraising and external engagement.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country program annex required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-PROG-008", "name": "Stakeholder Engagement, Community Participation, and Social Accountability Framework", "type": "Framework", "owner": "Programs / MEAL", "number": "55", "status": "Awaiting Upload", "version": "", "category": "Programs, Grants & Partnerships", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial", "sensitivity": "Controlled", "categoryCode": "PROG", "effectiveDate": "", "controlPurpose": "Program quality, grants, partners, beneficiaries, fundraising and external engagement.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country/community adaptation required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-OPS-001", "name": "Contract Development and Contract-Management Policy", "type": "Policy", "owner": "Legal / Procurement", "number": "56", "status": "Awaiting Upload", "version": "", "category": "Operations & Country Infrastructure", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "OPS", "effectiveDate": "", "controlPurpose": "Contracts, country establishment, facilities, inventory, transport and physical operations.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country contract law required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-OPS-002", "name": "Country-Office Establishment and Closure Manual", "type": "Manual", "owner": "Executive Director / Legal / Finance", "number": "57", "status": "Awaiting Upload", "version": "", "category": "Operations & Country Infrastructure", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + country event", "sensitivity": "Controlled", "categoryCode": "OPS", "effectiveDate": "", "controlPurpose": "Contracts, country establishment, facilities, inventory, transport and physical operations.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country legal plan required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-OPS-003", "name": "Inventory, Warehousing, and Supplies-Control Manual", "type": "Manual", "owner": "Operations / Finance", "number": "58", "status": "Awaiting Upload", "version": "", "category": "Operations & Country Infrastructure", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "OPS", "effectiveDate": "", "controlPurpose": "Contracts, country establishment, facilities, inventory, transport and physical operations.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director under Board policy", "countryApplicability": "Country warehouse/tax required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-OPS-004", "name": "Physical Security, Office Access, and Visitor-Control Policy", "type": "Policy", "owner": "Security / Operations", "number": "59", "status": "Awaiting Upload", "version": "", "category": "Operations & Country Infrastructure", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual + threat", "sensitivity": "Controlled", "categoryCode": "OPS", "effectiveDate": "", "controlPurpose": "Contracts, country establishment, facilities, inventory, transport and physical operations.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director under Board policy", "countryApplicability": "Country site plan required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-OPS-005", "name": "Vehicle, Transportation, and Fuel-Management Policy", "type": "Policy", "owner": "Operations / Finance", "number": "60", "status": "Awaiting Upload", "version": "", "category": "Operations & Country Infrastructure", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "OPS", "effectiveDate": "", "controlPurpose": "Contracts, country establishment, facilities, inventory, transport and physical operations.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country transport/fuel schedule required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-STRAT-001", "name": "Digital Governance, Enterprise Architecture, and Technology Investment Manual", "type": "Manual", "owner": "CIO / Executive Director", "number": "61", "status": "Awaiting Upload", "version": "", "category": "Strategy, Quality & Innovation", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "STRAT", "effectiveDate": "", "controlPurpose": "Planning, transformation, quality improvement, sustainability, knowledge and technology investment.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country technology roadmap", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-STRAT-002", "name": "Environmental Sustainability, Climate Risk, and Responsible Operations Policy", "type": "Policy", "owner": "Operations / Risk", "number": "62", "status": "Awaiting Upload", "version": "", "category": "Strategy, Quality & Innovation", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial", "sensitivity": "Controlled", "categoryCode": "STRAT", "effectiveDate": "", "controlPurpose": "Planning, transformation, quality improvement, sustainability, knowledge and technology investment.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country climate plan required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-STRAT-003", "name": "Intellectual Property, Research, Innovation, and Knowledge-Management Policy", "type": "Policy", "owner": "Legal / Innovation", "number": "63", "status": "Awaiting Upload", "version": "", "category": "Strategy, Quality & Innovation", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial + law", "sensitivity": "Controlled", "categoryCode": "STRAT", "effectiveDate": "", "controlPurpose": "Planning, transformation, quality improvement, sustainability, knowledge and technology investment.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country IP law required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-STRAT-004", "name": "Organizational Change Management and Transformation Manual", "type": "Manual", "owner": "Executive Director / HR", "number": "64", "status": "Awaiting Upload", "version": "", "category": "Strategy, Quality & Innovation", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Biennial + change", "sensitivity": "Controlled", "categoryCode": "STRAT", "effectiveDate": "", "controlPurpose": "Planning, transformation, quality improvement, sustainability, knowledge and technology investment.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director", "countryApplicability": "Country change plan as needed", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-STRAT-005", "name": "Organizational Quality Management and Continuous Improvement Manual", "type": "Manual", "owner": "Quality Lead / Executive Director", "number": "65", "status": "Awaiting Upload", "version": "", "category": "Strategy, Quality & Innovation", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "STRAT", "effectiveDate": "", "controlPurpose": "Planning, transformation, quality improvement, sustainability, knowledge and technology investment.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director", "countryApplicability": "Country quality plan required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-STRAT-006", "name": "Strategic Planning, Annual Operating Planning, and Organizational Performance Management Manual", "type": "Manual", "owner": "Executive Director / Strategy", "number": "66", "status": "Awaiting Upload", "version": "", "category": "Strategy, Quality & Innovation", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "STRAT", "effectiveDate": "", "controlPurpose": "Planning, transformation, quality improvement, sustainability, knowledge and technology investment.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country operating plan required", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-LIB-001", "name": "Adoption, Signature, and Document-Control Pages Toolkit", "type": "Toolkit", "owner": "Governance/Compliance Administrator", "number": "67", "status": "Awaiting Upload", "version": "", "category": "Controlled-Library Administration", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "LIB", "effectiveDate": "", "controlPurpose": "Document control, adoption tools, master indexing and official library administration.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Executive Director under Board policy", "countryApplicability": "Global forms; local signatures", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-LIB-002", "name": "Policy Approval, Version Control, and Retention Requirements Manual", "type": "Manual", "owner": "Governance / Records", "number": "68", "status": "Awaiting Upload", "version": "", "category": "Controlled-Library Administration", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Annual", "sensitivity": "Controlled", "categoryCode": "LIB", "effectiveDate": "", "controlPurpose": "Document control, adoption tools, master indexing and official library administration.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "Country records/legal supplement", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-LIB-003", "name": "Controlled Policy Library Master Index, Implementation Roadmap, and Compliance Rollout Plan", "type": "Plan", "owner": "Governance / Compliance", "number": "69", "status": "Awaiting Upload", "version": "", "category": "Controlled-Library Administration", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Quarterly rollout; annual later", "sensitivity": "Controlled", "categoryCode": "LIB", "effectiveDate": "", "controlPurpose": "Document control, adoption tools, master indexing and official library administration.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "All five countries", "masterRegisterStatus": "1.0 / approval pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}, {"id": "T4FG-LIB-004", "name": "Master Official Register, Controlled Policy Library, Implementation Roadmap, and Five-Country Compliance Rollout Plan", "type": "Plan", "owner": "Governance / Compliance", "number": "70", "status": "Awaiting Upload", "version": "2.0", "category": "Controlled-Library Administration", "priority": "Official Catalogue", "uploadedAt": "", "uploadedBy": "", "changeNotes": "", "publishedAt": "", "publishedBy": "", "reviewCycle": "Quarterly rollout; annual later", "sensitivity": "Controlled", "categoryCode": "LIB", "effectiveDate": "", "controlPurpose": "Document control, adoption tools, master indexing and official library administration.", "workflowStatus": "Awaiting Upload", "workingSummary": "", "sourceCatalogue": "T4FG-LIB-004", "uploadedFileName": "", "approvalAuthority": "Global Board", "countryApplicability": "All five countries", "masterRegisterStatus": "2.0 / Board adoption pending", "sourceCatalogueVersion": "2.0 — Reconciled Global Board adoption draft"}], "timeEntries": [], "projectTasks": [], "contributions": [], "organizations": [{"id": "t4f-hq", "name": "Tech4Future-Global Headquarters", "type": "t4f_hq", "status": "Active", "country": "United States", "parentId": null}, {"id": "fmw", "name": "FMW Nonprofit Solutions", "type": "fiscal_sponsor", "status": "Active", "country": "United States", "parentId": null}, {"id": "t4f-benin", "name": "Tech4Future-Benin", "type": "country_office", "status": "Planned", "country": "Benin", "parentId": "t4f-hq"}, {"id": "t4f-burkina-faso", "name": "Tech4Future-Burkina Faso", "type": "country_office", "status": "Planned", "country": "Burkina Faso", "parentId": "t4f-hq"}, {"id": "t4f-cabo-verde", "name": "Tech4Future-Cabo Verde", "type": "country_office", "status": "Planned", "country": "Cabo Verde", "parentId": "t4f-hq"}, {"id": "t4f-cote-divoire", "name": "Tech4Future-Côte d’Ivoire", "type": "country_office", "status": "Planned", "country": "Côte d’Ivoire", "parentId": "t4f-hq"}, {"id": "t4f-the-gambia", "name": "Tech4Future-The Gambia", "type": "country_office", "status": "Planned", "country": "The Gambia", "parentId": "t4f-hq"}, {"id": "t4f-ghana", "name": "Tech4Future-Ghana", "type": "country_office", "status": "Planned", "country": "Ghana", "parentId": "t4f-hq"}, {"id": "t4f-guinea", "name": "Tech4Future-Guinea", "type": "country_office", "status": "Planned", "country": "Guinea", "parentId": "t4f-hq"}, {"id": "t4f-guinea-bissau", "name": "Tech4Future-Guinea-Bissau", "type": "country_office", "status": "Planned", "country": "Guinea-Bissau", "parentId": "t4f-hq"}, {"id": "t4f-liberia", "name": "Tech4Future-Liberia", "type": "country_office", "status": "Active", "country": "Liberia", "parentId": "t4f-hq"}, {"id": "t4f-mali", "name": "Tech4Future-Mali", "type": "country_office", "status": "Planned", "country": "Mali", "parentId": "t4f-hq"}, {"id": "t4f-mauritania", "name": "Tech4Future-Mauritania", "type": "country_office", "status": "Planned", "country": "Mauritania", "parentId": "t4f-hq"}, {"id": "t4f-niger", "name": "Tech4Future-Niger", "type": "country_office", "status": "Planned", "country": "Niger", "parentId": "t4f-hq"}, {"id": "t4f-nigeria", "name": "Tech4Future-Nigeria", "type": "country_office", "status": "Planned", "country": "Nigeria", "parentId": "t4f-hq"}, {"id": "t4f-senegal", "name": "Tech4Future-Senegal", "type": "country_office", "status": "Planned", "country": "Senegal", "parentId": "t4f-hq"}, {"id": "t4f-sierra-leone", "name": "Tech4Future-Sierra Leone", "type": "country_office", "status": "Planned", "country": "Sierra Leone", "parentId": "t4f-hq"}, {"id": "t4f-togo", "name": "Tech4Future-Togo", "type": "country_office", "status": "Planned", "country": "Togo", "parentId": "t4f-hq"}], "reportReviews": [], "financeRecords": [], "documentReviews": [], "documentVersions": [], "projectDocuments": [], "attendanceReports": []}	1
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 60, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 15, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 19, true);


--
-- Name: platform_core_platformprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.platform_core_platformprofile_id_seq', 1, true);


--
-- Name: platform_core_platformrecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: t4f_app
--

SELECT pg_catalog.setval('public.platform_core_platformrecord_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: platform_core_apisession platform_core_apisession_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_apisession
    ADD CONSTRAINT platform_core_apisession_pkey PRIMARY KEY (id);


--
-- Name: platform_core_apisession platform_core_apisession_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_apisession
    ADD CONSTRAINT platform_core_apisession_token_hash_key UNIQUE (token_hash);


--
-- Name: platform_core_auditevent platform_core_auditevent_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_auditevent
    ADD CONSTRAINT platform_core_auditevent_pkey PRIMARY KEY (id);


--
-- Name: platform_core_fileobject platform_core_fileobject_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_fileobject
    ADD CONSTRAINT platform_core_fileobject_pkey PRIMARY KEY (id);


--
-- Name: platform_core_invitation platform_core_invitation_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_invitation
    ADD CONSTRAINT platform_core_invitation_pkey PRIMARY KEY (id);


--
-- Name: platform_core_invitation platform_core_invitation_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_invitation
    ADD CONSTRAINT platform_core_invitation_token_hash_key UNIQUE (token_hash);


--
-- Name: platform_core_organization platform_core_organization_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_organization
    ADD CONSTRAINT platform_core_organization_pkey PRIMARY KEY (id);


--
-- Name: platform_core_platformprofile platform_core_platformprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_platformprofile
    ADD CONSTRAINT platform_core_platformprofile_pkey PRIMARY KEY (id);


--
-- Name: platform_core_platformprofile platform_core_platformprofile_platform_user_id_key; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_platformprofile
    ADD CONSTRAINT platform_core_platformprofile_platform_user_id_key UNIQUE (platform_user_id);


--
-- Name: platform_core_platformprofile platform_core_platformprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_platformprofile
    ADD CONSTRAINT platform_core_platformprofile_user_id_key UNIQUE (user_id);


--
-- Name: platform_core_platformrecord platform_core_platformrecord_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_platformrecord
    ADD CONSTRAINT platform_core_platformrecord_pkey PRIMARY KEY (id);


--
-- Name: platform_core_position platform_core_position_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_position
    ADD CONSTRAINT platform_core_position_pkey PRIMARY KEY (id);


--
-- Name: platform_core_workspacestate platform_core_workspacestate_pkey; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_workspacestate
    ADD CONSTRAINT platform_core_workspacestate_pkey PRIMARY KEY (key);


--
-- Name: platform_core_platformrecord uniq_platform_record; Type: CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_platformrecord
    ADD CONSTRAINT uniq_platform_record UNIQUE (workspace_key, record_type, record_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: platform_co_record__8a2911_idx; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_co_record__8a2911_idx ON public.platform_core_platformrecord USING btree (record_type, status);


--
-- Name: platform_co_record__9bc5c1_idx; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_co_record__9bc5c1_idx ON public.platform_core_platformrecord USING btree (record_type, organization_id);


--
-- Name: platform_core_apisession_expires_at_93debae3; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_apisession_expires_at_93debae3 ON public.platform_core_apisession USING btree (expires_at);


--
-- Name: platform_core_apisession_token_hash_e9cc032a_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_apisession_token_hash_e9cc032a_like ON public.platform_core_apisession USING btree (token_hash varchar_pattern_ops);


--
-- Name: platform_core_apisession_user_id_f8fccf6b; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_apisession_user_id_f8fccf6b ON public.platform_core_apisession USING btree (user_id);


--
-- Name: platform_core_auditevent_action_5abd11b4; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_action_5abd11b4 ON public.platform_core_auditevent USING btree (action);


--
-- Name: platform_core_auditevent_action_5abd11b4_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_action_5abd11b4_like ON public.platform_core_auditevent USING btree (action varchar_pattern_ops);


--
-- Name: platform_core_auditevent_actor_id_ae148574; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_actor_id_ae148574 ON public.platform_core_auditevent USING btree (actor_id);


--
-- Name: platform_core_auditevent_entity_id_778502c7; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_entity_id_778502c7 ON public.platform_core_auditevent USING btree (entity_id);


--
-- Name: platform_core_auditevent_entity_id_778502c7_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_entity_id_778502c7_like ON public.platform_core_auditevent USING btree (entity_id varchar_pattern_ops);


--
-- Name: platform_core_auditevent_entity_type_99891c4d; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_entity_type_99891c4d ON public.platform_core_auditevent USING btree (entity_type);


--
-- Name: platform_core_auditevent_entity_type_99891c4d_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_entity_type_99891c4d_like ON public.platform_core_auditevent USING btree (entity_type varchar_pattern_ops);


--
-- Name: platform_core_auditevent_occurred_at_e287ed7c; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_occurred_at_e287ed7c ON public.platform_core_auditevent USING btree (occurred_at);


--
-- Name: platform_core_auditevent_organization_id_dd9f8f97; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_organization_id_dd9f8f97 ON public.platform_core_auditevent USING btree (organization_id);


--
-- Name: platform_core_auditevent_organization_id_dd9f8f97_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_auditevent_organization_id_dd9f8f97_like ON public.platform_core_auditevent USING btree (organization_id varchar_pattern_ops);


--
-- Name: platform_core_fileobject_category_46c31a50; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_fileobject_category_46c31a50 ON public.platform_core_fileobject USING btree (category);


--
-- Name: platform_core_fileobject_category_46c31a50_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_fileobject_category_46c31a50_like ON public.platform_core_fileobject USING btree (category varchar_pattern_ops);


--
-- Name: platform_core_fileobject_organization_id_b9a5561c; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_fileobject_organization_id_b9a5561c ON public.platform_core_fileobject USING btree (organization_id);


--
-- Name: platform_core_fileobject_organization_id_b9a5561c_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_fileobject_organization_id_b9a5561c_like ON public.platform_core_fileobject USING btree (organization_id varchar_pattern_ops);


--
-- Name: platform_core_fileobject_owner_id_e8ba510a; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_fileobject_owner_id_e8ba510a ON public.platform_core_fileobject USING btree (owner_id);


--
-- Name: platform_core_fileobject_sha256_90e5c52c; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_fileobject_sha256_90e5c52c ON public.platform_core_fileobject USING btree (sha256);


--
-- Name: platform_core_fileobject_sha256_90e5c52c_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_fileobject_sha256_90e5c52c_like ON public.platform_core_fileobject USING btree (sha256 varchar_pattern_ops);


--
-- Name: platform_core_invitation_email_797f6570; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_invitation_email_797f6570 ON public.platform_core_invitation USING btree (email);


--
-- Name: platform_core_invitation_email_797f6570_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_invitation_email_797f6570_like ON public.platform_core_invitation USING btree (email varchar_pattern_ops);


--
-- Name: platform_core_invitation_expires_at_9d453a46; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_invitation_expires_at_9d453a46 ON public.platform_core_invitation USING btree (expires_at);


--
-- Name: platform_core_invitation_invited_by_id_a2bf0649; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_invitation_invited_by_id_a2bf0649 ON public.platform_core_invitation USING btree (invited_by_id);


--
-- Name: platform_core_invitation_organization_id_ad0ec2b5; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_invitation_organization_id_ad0ec2b5 ON public.platform_core_invitation USING btree (organization_id);


--
-- Name: platform_core_invitation_organization_id_ad0ec2b5_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_invitation_organization_id_ad0ec2b5_like ON public.platform_core_invitation USING btree (organization_id varchar_pattern_ops);


--
-- Name: platform_core_invitation_token_hash_06529885_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_invitation_token_hash_06529885_like ON public.platform_core_invitation USING btree (token_hash varchar_pattern_ops);


--
-- Name: platform_core_organization_country_bc77f3ad; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_organization_country_bc77f3ad ON public.platform_core_organization USING btree (country);


--
-- Name: platform_core_organization_country_bc77f3ad_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_organization_country_bc77f3ad_like ON public.platform_core_organization USING btree (country varchar_pattern_ops);


--
-- Name: platform_core_organization_id_3624710e_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_organization_id_3624710e_like ON public.platform_core_organization USING btree (id varchar_pattern_ops);


--
-- Name: platform_core_organization_organization_type_bd3594bf; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_organization_organization_type_bd3594bf ON public.platform_core_organization USING btree (organization_type);


--
-- Name: platform_core_organization_organization_type_bd3594bf_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_organization_organization_type_bd3594bf_like ON public.platform_core_organization USING btree (organization_type varchar_pattern_ops);


--
-- Name: platform_core_organization_status_c66743e4; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_organization_status_c66743e4 ON public.platform_core_organization USING btree (status);


--
-- Name: platform_core_organization_status_c66743e4_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_organization_status_c66743e4_like ON public.platform_core_organization USING btree (status varchar_pattern_ops);


--
-- Name: platform_core_platformprofile_organization_id_9e781a6c; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_organization_id_9e781a6c ON public.platform_core_platformprofile USING btree (organization_id);


--
-- Name: platform_core_platformprofile_organization_id_9e781a6c_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_organization_id_9e781a6c_like ON public.platform_core_platformprofile USING btree (organization_id varchar_pattern_ops);


--
-- Name: platform_core_platformprofile_platform_user_id_07c29b31_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_platform_user_id_07c29b31_like ON public.platform_core_platformprofile USING btree (platform_user_id varchar_pattern_ops);


--
-- Name: platform_core_platformprofile_position_id_7f9ce93e; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_position_id_7f9ce93e ON public.platform_core_platformprofile USING btree (position_id);


--
-- Name: platform_core_platformprofile_position_id_7f9ce93e_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_position_id_7f9ce93e_like ON public.platform_core_platformprofile USING btree (position_id varchar_pattern_ops);


--
-- Name: platform_core_platformprofile_status_1826b8ef; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_status_1826b8ef ON public.platform_core_platformprofile USING btree (status);


--
-- Name: platform_core_platformprofile_status_1826b8ef_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_status_1826b8ef_like ON public.platform_core_platformprofile USING btree (status varchar_pattern_ops);


--
-- Name: platform_core_platformprofile_system_role_6a372426; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_system_role_6a372426 ON public.platform_core_platformprofile USING btree (system_role);


--
-- Name: platform_core_platformprofile_system_role_6a372426_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformprofile_system_role_6a372426_like ON public.platform_core_platformprofile USING btree (system_role varchar_pattern_ops);


--
-- Name: platform_core_platformrecord_country_790631cd; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_country_790631cd ON public.platform_core_platformrecord USING btree (country);


--
-- Name: platform_core_platformrecord_country_790631cd_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_country_790631cd_like ON public.platform_core_platformrecord USING btree (country varchar_pattern_ops);


--
-- Name: platform_core_platformrecord_organization_id_d9fd22e0; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_organization_id_d9fd22e0 ON public.platform_core_platformrecord USING btree (organization_id);


--
-- Name: platform_core_platformrecord_organization_id_d9fd22e0_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_organization_id_d9fd22e0_like ON public.platform_core_platformrecord USING btree (organization_id varchar_pattern_ops);


--
-- Name: platform_core_platformrecord_record_type_35f5ee08; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_record_type_35f5ee08 ON public.platform_core_platformrecord USING btree (record_type);


--
-- Name: platform_core_platformrecord_record_type_35f5ee08_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_record_type_35f5ee08_like ON public.platform_core_platformrecord USING btree (record_type varchar_pattern_ops);


--
-- Name: platform_core_platformrecord_status_3de215ba; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_status_3de215ba ON public.platform_core_platformrecord USING btree (status);


--
-- Name: platform_core_platformrecord_status_3de215ba_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_status_3de215ba_like ON public.platform_core_platformrecord USING btree (status varchar_pattern_ops);


--
-- Name: platform_core_platformrecord_user_ref_5e2c631d; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_user_ref_5e2c631d ON public.platform_core_platformrecord USING btree (user_ref);


--
-- Name: platform_core_platformrecord_user_ref_5e2c631d_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_user_ref_5e2c631d_like ON public.platform_core_platformrecord USING btree (user_ref varchar_pattern_ops);


--
-- Name: platform_core_platformrecord_workspace_key_c54d1d98; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_workspace_key_c54d1d98 ON public.platform_core_platformrecord USING btree (workspace_key);


--
-- Name: platform_core_platformrecord_workspace_key_c54d1d98_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_platformrecord_workspace_key_c54d1d98_like ON public.platform_core_platformrecord USING btree (workspace_key varchar_pattern_ops);


--
-- Name: platform_core_position_family_b9099e95; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_position_family_b9099e95 ON public.platform_core_position USING btree (family);


--
-- Name: platform_core_position_family_b9099e95_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_position_family_b9099e95_like ON public.platform_core_position USING btree (family varchar_pattern_ops);


--
-- Name: platform_core_position_id_eefe835d_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_position_id_eefe835d_like ON public.platform_core_position USING btree (id varchar_pattern_ops);


--
-- Name: platform_core_workspacestate_key_b4ba92f6_like; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_workspacestate_key_b4ba92f6_like ON public.platform_core_workspacestate USING btree (key varchar_pattern_ops);


--
-- Name: platform_core_workspacestate_last_saved_by_id_04534df2; Type: INDEX; Schema: public; Owner: t4f_app
--

CREATE INDEX platform_core_workspacestate_last_saved_by_id_04534df2 ON public.platform_core_workspacestate USING btree (last_saved_by_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_apisession platform_core_apisession_user_id_f8fccf6b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_apisession
    ADD CONSTRAINT platform_core_apisession_user_id_f8fccf6b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_auditevent platform_core_auditevent_actor_id_ae148574_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_auditevent
    ADD CONSTRAINT platform_core_auditevent_actor_id_ae148574_fk_auth_user_id FOREIGN KEY (actor_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_fileobject platform_core_fileobject_owner_id_e8ba510a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_fileobject
    ADD CONSTRAINT platform_core_fileobject_owner_id_e8ba510a_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_invitation platform_core_invita_organization_id_ad0ec2b5_fk_platform_; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_invitation
    ADD CONSTRAINT platform_core_invita_organization_id_ad0ec2b5_fk_platform_ FOREIGN KEY (organization_id) REFERENCES public.platform_core_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_invitation platform_core_invitation_invited_by_id_a2bf0649_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_invitation
    ADD CONSTRAINT platform_core_invitation_invited_by_id_a2bf0649_fk_auth_user_id FOREIGN KEY (invited_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_platformprofile platform_core_platfo_organization_id_9e781a6c_fk_platform_; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_platformprofile
    ADD CONSTRAINT platform_core_platfo_organization_id_9e781a6c_fk_platform_ FOREIGN KEY (organization_id) REFERENCES public.platform_core_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_platformprofile platform_core_platfo_position_id_7f9ce93e_fk_platform_; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_platformprofile
    ADD CONSTRAINT platform_core_platfo_position_id_7f9ce93e_fk_platform_ FOREIGN KEY (position_id) REFERENCES public.platform_core_position(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_platformprofile platform_core_platformprofile_user_id_d87b5254_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_platformprofile
    ADD CONSTRAINT platform_core_platformprofile_user_id_d87b5254_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: platform_core_workspacestate platform_core_worksp_last_saved_by_id_04534df2_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: t4f_app
--

ALTER TABLE ONLY public.platform_core_workspacestate
    ADD CONSTRAINT platform_core_worksp_last_saved_by_id_04534df2_fk_auth_user FOREIGN KEY (last_saved_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict 9focJabtWCfKmUBWHc8a9CgdGzpnTeKJkzOqHksPof11alCX6gJ9uYOd6yCtgBW

